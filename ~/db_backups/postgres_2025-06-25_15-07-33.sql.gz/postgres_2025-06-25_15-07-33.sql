--
-- PostgreSQL database dump
--

-- Dumped from database version 15.8
-- Dumped by pg_dump version 16.9 (Ubuntu 16.9-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- Name: pg_net; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_net; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_net IS 'Async HTTP';


--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- Name: pgmq; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA pgmq;


ALTER SCHEMA pgmq OWNER TO postgres;

--
-- Name: pgmq_public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA pgmq_public;


ALTER SCHEMA pgmq_public OWNER TO postgres;

--
-- Name: private; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA private;


ALTER SCHEMA private OWNER TO postgres;

--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- Name: supabase_functions; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA supabase_functions;


ALTER SCHEMA supabase_functions OWNER TO supabase_admin;

--
-- Name: supabase_migrations; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA supabase_migrations;


ALTER SCHEMA supabase_migrations OWNER TO postgres;

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_graphql WITH SCHEMA graphql;


--
-- Name: EXTENSION pg_graphql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_graphql IS 'pg_graphql: GraphQL support';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: pgjwt; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgjwt WITH SCHEMA extensions;


--
-- Name: EXTENSION pgjwt; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgjwt IS 'JSON Web Token API for Postgresql';


--
-- Name: pgmq; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgmq WITH SCHEMA pgmq;


--
-- Name: EXTENSION pgmq; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgmq IS 'A lightweight message queue. Like AWS SQS and RSMQ but on Postgres.';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO supabase_admin;

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE realtime.equality_op OWNER TO supabase_admin;

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


ALTER TYPE realtime.user_defined_filter OWNER TO supabase_admin;

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO supabase_admin;

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO supabase_admin;

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
  BEGIN
    IF EXISTS (
      SELECT 1
      FROM pg_event_trigger_ddl_commands() AS ev
      JOIN pg_extension AS ext
      ON ev.objid = ext.oid
      WHERE ext.extname = 'pg_net'
    )
    THEN
      GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

      IF EXISTS (
        SELECT FROM pg_extension
        WHERE extname = 'pg_net'
        -- all versions in use on existing projects as of 2025-02-20
        -- version 0.12.0 onwards don't need these applied
        AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
      ) THEN
        ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
        ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

        ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
        ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

        REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
        REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

        GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
        GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      END IF;
    END IF;
  END;
  $$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $_$
begin
    raise debug 'PgBouncer auth request: %', p_usename;

    return query
    select 
        rolname::text, 
        case when rolvaliduntil < now() 
            then null 
            else rolpassword::text 
        end 
    from pg_authid 
    where rolname=$1 and rolcanlogin;
end;
$_$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO supabase_admin;

--
-- Name: archive(text, bigint); Type: FUNCTION; Schema: pgmq_public; Owner: postgres
--

CREATE FUNCTION pgmq_public.archive(queue_name text, message_id bigint) RETURNS boolean
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
begin
    return pgmq.archive(queue_name := queue_name, msg_id := message_id);
end;
$$;


ALTER FUNCTION pgmq_public.archive(queue_name text, message_id bigint) OWNER TO postgres;

--
-- Name: FUNCTION archive(queue_name text, message_id bigint); Type: COMMENT; Schema: pgmq_public; Owner: postgres
--

COMMENT ON FUNCTION pgmq_public.archive(queue_name text, message_id bigint) IS 'Archives a message by moving it from the queue to a permanent archive.';


--
-- Name: delete(text, bigint); Type: FUNCTION; Schema: pgmq_public; Owner: postgres
--

CREATE FUNCTION pgmq_public.delete(queue_name text, message_id bigint) RETURNS boolean
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
begin
    return pgmq.delete(queue_name := queue_name, msg_id := message_id);
end;
$$;


ALTER FUNCTION pgmq_public.delete(queue_name text, message_id bigint) OWNER TO postgres;

--
-- Name: FUNCTION delete(queue_name text, message_id bigint); Type: COMMENT; Schema: pgmq_public; Owner: postgres
--

COMMENT ON FUNCTION pgmq_public.delete(queue_name text, message_id bigint) IS 'Permanently deletes a message from the specified queue.';


--
-- Name: pop(text); Type: FUNCTION; Schema: pgmq_public; Owner: postgres
--

CREATE FUNCTION pgmq_public.pop(queue_name text) RETURNS SETOF pgmq.message_record
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
begin
    return query
    select * from pgmq.pop(queue_name := queue_name);
end;
$$;


ALTER FUNCTION pgmq_public.pop(queue_name text) OWNER TO postgres;

--
-- Name: FUNCTION pop(queue_name text); Type: COMMENT; Schema: pgmq_public; Owner: postgres
--

COMMENT ON FUNCTION pgmq_public.pop(queue_name text) IS 'Retrieves and locks the next message from the specified queue.';


--
-- Name: read(text, integer, integer); Type: FUNCTION; Schema: pgmq_public; Owner: postgres
--

CREATE FUNCTION pgmq_public.read(queue_name text, sleep_seconds integer, n integer) RETURNS SETOF pgmq.message_record
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
begin
    return query
    select * from pgmq.read(queue_name := queue_name, vt := sleep_seconds, qty := n);
end;
$$;


ALTER FUNCTION pgmq_public.read(queue_name text, sleep_seconds integer, n integer) OWNER TO postgres;

--
-- Name: FUNCTION read(queue_name text, sleep_seconds integer, n integer); Type: COMMENT; Schema: pgmq_public; Owner: postgres
--

COMMENT ON FUNCTION pgmq_public.read(queue_name text, sleep_seconds integer, n integer) IS 'Reads up to "n" messages from the specified queue with an optional "sleep_seconds" (visibility timeout).';


--
-- Name: send(text, jsonb, integer); Type: FUNCTION; Schema: pgmq_public; Owner: postgres
--

CREATE FUNCTION pgmq_public.send(queue_name text, message jsonb, sleep_seconds integer DEFAULT 0) RETURNS SETOF bigint
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
begin
    return query
    select * from pgmq.send(queue_name := queue_name, msg := message, delay := sleep_seconds);
end;
$$;


ALTER FUNCTION pgmq_public.send(queue_name text, message jsonb, sleep_seconds integer) OWNER TO postgres;

--
-- Name: FUNCTION send(queue_name text, message jsonb, sleep_seconds integer); Type: COMMENT; Schema: pgmq_public; Owner: postgres
--

COMMENT ON FUNCTION pgmq_public.send(queue_name text, message jsonb, sleep_seconds integer) IS 'Sends a message to the specified queue, optionally delaying its availability by a number of seconds.';


--
-- Name: send_batch(text, jsonb[], integer); Type: FUNCTION; Schema: pgmq_public; Owner: postgres
--

CREATE FUNCTION pgmq_public.send_batch(queue_name text, messages jsonb[], sleep_seconds integer DEFAULT 0) RETURNS SETOF bigint
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
begin
    return query
    select * from pgmq.send_batch(queue_name := queue_name, msgs := messages, delay := sleep_seconds);
end;
$$;


ALTER FUNCTION pgmq_public.send_batch(queue_name text, messages jsonb[], sleep_seconds integer) OWNER TO postgres;

--
-- Name: FUNCTION send_batch(queue_name text, messages jsonb[], sleep_seconds integer); Type: COMMENT; Schema: pgmq_public; Owner: postgres
--

COMMENT ON FUNCTION pgmq_public.send_batch(queue_name text, messages jsonb[], sleep_seconds integer) IS 'Sends a batch of messages to the specified queue, optionally delaying their availability by a number of seconds.';


--
-- Name: check_queue_size_and_trigger(); Type: FUNCTION; Schema: private; Owner: postgres
--

CREATE FUNCTION private.check_queue_size_and_trigger() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'private'
    AS $$
DECLARE
  queue_size INTEGER;
  worker_url TEXT;
  queue_max INTEGER = 1;
  worker_timeout_ms INTEGER = 5000;
  supabase_service_role_key TEXT;
  auth_token TEXT;
  http_request_id bigint;
  response_status INTEGER;
  response_body TEXT;
  response_headers jsonb;
BEGIN

  SELECT count(*) INTO queue_size 
  FROM pgmq."q_image-processing";

  insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] queue size: ' || queue_size);
  
  IF queue_size >= queue_max THEN
    worker_url := (select decrypted_secret from vault.decrypted_secrets where name = 'worker_url');
    supabase_service_role_key := (select decrypted_secret from vault.decrypted_secrets where name = 'supabase_service_role_key');

    if worker_url IS NULL THEN
      insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] worker_url is NULL');
    END IF;

    if supabase_service_role_key IS NULL THEN
      insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] supabase_service_role_key is NULL');
    END IF;

    auth_token := 'Bearer ' || supabase_service_role_key;

    
    -- Trigger worker
    IF worker_url IS NOT NULL THEN
      insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Making HTTP POST to: ' || worker_url);
      
      BEGIN
        -- Make HTTP request and get the request ID
        SELECT net.http_post(
          url:=worker_url,
          headers:= jsonb_build_object(
          'Content-Type','application/json',
          'Authorization', auth_token
        ),
          timeout_milliseconds:=worker_timeout_ms
        ) INTO http_request_id;
        
        insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] HTTP request submitted, ID: ' || http_request_id);
        
        -- Wait for the request to complete (pg_net is async)
        PERFORM pg_sleep(3);
        
        -- Get the response from net._http_response table (note the underscore)
        BEGIN
          SELECT status_code, content, headers, timed_out, error_msg
          INTO response_status, response_body, response_headers
          FROM net._http_response 
          WHERE id = http_request_id;
          
          -- Check if we found a response
          IF NOT FOUND THEN
            insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] No response found for request ID: ' || http_request_id);
            
            -- Let's see what's in the response table
            insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Checking all responses in table...');
            
            -- Log recent responses to debug
            FOR response_status, response_body IN 
              SELECT status_code, content 
              FROM net._http_response 
              ORDER BY created DESC 
              LIMIT 3
            LOOP
              insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Recent response - Status: ' || COALESCE(response_status::text, 'NULL') || ', Body: ' || COALESCE(response_body, 'NULL'));
            END LOOP;
            
          END IF;
          
        EXCEPTION WHEN OTHERS THEN
          insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Error querying _http_response table: ' || SQLERRM);
        END;
        
        insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Response Status: ' || COALESCE(response_status::text, 'NULL'));
        insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Response Body: ' || COALESCE(response_body, 'NULL'));
        insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Response Headers: ' || COALESCE(response_headers::text, 'NULL'));
        
      EXCEPTION WHEN OTHERS THEN
        insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] HTTP POST ERROR: ' || SQLERRM);
        insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] SQLSTATE: ' || SQLSTATE);
      END;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;


ALTER FUNCTION private.check_queue_size_and_trigger() OWNER TO postgres;

--
-- Name: export_companies_csv(); Type: FUNCTION; Schema: private; Owner: postgres
--

CREATE FUNCTION private.export_companies_csv() RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'private'
    AS $$
DECLARE
    csv_output TEXT;
BEGIN
    SELECT string_agg(csv_row, E'\n') INTO csv_output
    FROM (
        SELECT 'name,industry,primary_email,email_list,primary_phone,phone_list,city,state,status,group' AS csv_row
        UNION ALL
        SELECT 
            quote_literal(name) || ',' ||
            quote_literal(array_to_string(industry, ';')) || ',' ||
            quote_literal(COALESCE(primary_email, '')) || ',' ||
            quote_literal(array_to_string(email, ';')) || ',' ||
            quote_literal(COALESCE(primary_phone, '')) || ',' ||
            quote_literal(array_to_string(phone, ';')) || ',' ||
            quote_literal(COALESCE(city, '')) || ',' ||
            quote_literal(COALESCE(state, '')) || ',' ||
            quote_literal(COALESCE(status, '')) || ',' ||
            quote_literal(COALESCE("group", '')) AS csv_row
        FROM public.companies
    ) all_data;
    
    RETURN COALESCE(csv_output, '');
END;
$$;


ALTER FUNCTION private.export_companies_csv() OWNER TO postgres;

--
-- Name: export_contacts_csv(); Type: FUNCTION; Schema: private; Owner: postgres
--

CREATE FUNCTION private.export_contacts_csv() RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'private'
    AS $$
DECLARE
    csv_output TEXT;
BEGIN
    SELECT string_agg(csv_row, E'\n') INTO csv_output
    FROM (
        SELECT 'company_name,contact_name,title,email,phone,message' AS csv_row
        UNION ALL
        SELECT 
            quote_literal(c.name) || ',' ||
            quote_literal(COALESCE(ct.name, '')) || ',' ||
            quote_literal(COALESCE(ct.title, '')) || ',' ||
            quote_literal(COALESCE(ct.email, '')) || ',' ||
            quote_literal(COALESCE(ct.phone, '')) || ',' ||
            quote_literal(COALESCE(ct.message, '')) AS csv_row
        FROM public.contacts ct
        JOIN public.companies c ON ct.company_id = c.id
    ) all_data;
    
    RETURN COALESCE(csv_output, '');
END;
$$;


ALTER FUNCTION private.export_contacts_csv() OWNER TO postgres;

--
-- Name: normalize_company_name(text); Type: FUNCTION; Schema: private; Owner: postgres
--

CREATE FUNCTION private.normalize_company_name(name_input text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE SECURITY DEFINER
    SET search_path TO 'private'
    AS $$
BEGIN
    RETURN LOWER(
        TRIM(
            REGEXP_REPLACE(
                REGEXP_REPLACE(
                    name_input,
                    '[^\w\s]', '', 'g'
                ),
                '\b(inc|corp|llc|co|ltd|plc)\b', '', 'gi'
            )
        )
    );
END;
$$;


ALTER FUNCTION private.normalize_company_name(name_input text) OWNER TO postgres;

--
-- Name: normalize_email(text); Type: FUNCTION; Schema: private; Owner: postgres
--

CREATE FUNCTION private.normalize_email(email_input text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE SECURITY DEFINER
    SET search_path TO 'private'
    AS $$
BEGIN
    RETURN LOWER(TRIM(email_input));
END;
$$;


ALTER FUNCTION private.normalize_email(email_input text) OWNER TO postgres;

--
-- Name: normalize_phone(text); Type: FUNCTION; Schema: private; Owner: postgres
--

CREATE FUNCTION private.normalize_phone(phone_input text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE SECURITY DEFINER
    SET search_path TO 'private'
    AS $$
BEGIN
    RETURN REGEXP_REPLACE(phone_input, '\D', '', 'g');
END;
$$;


ALTER FUNCTION private.normalize_phone(phone_input text) OWNER TO postgres;

--
-- Name: upsert_company(text, text, text, text[], text, text); Type: FUNCTION; Schema: private; Owner: postgres
--

CREATE FUNCTION private.upsert_company(p_name text, p_email text, p_phone text, p_industry text[], p_city text, p_state text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'private'
    AS $$
DECLARE
    v_company_id UUID;
    v_normalized_name TEXT;
    v_normalized_email TEXT;
    v_normalized_phone TEXT;
BEGIN
    v_normalized_name := normalize_company_name(p_name);
    v_normalized_email := CASE WHEN p_email IS NOT NULL AND p_email != '' THEN normalize_email(p_email) ELSE NULL END;
    v_normalized_phone := CASE WHEN p_phone IS NOT NULL AND p_phone != '' THEN normalize_phone(p_phone) ELSE NULL END;

    -- Find existing company with priority: name, email, phone
    SELECT id INTO v_company_id 
    FROM public.companies 
    WHERE normalize_company_name(name) = v_normalized_name;

    -- If no name match and email provided, check for email match
    IF v_company_id IS NULL AND v_normalized_email IS NOT NULL THEN
        SELECT id INTO v_company_id 
        FROM public.companies 
        WHERE v_normalized_email = ANY(
            SELECT normalize_email(unnest(email))
            WHERE email IS NOT NULL AND email != '{}'
        ) OR normalize_email(primary_email) = v_normalized_email;
    END IF;

    -- If no name/email match and phone provided, check for phone match
    IF v_company_id IS NULL AND v_normalized_phone IS NOT NULL THEN
        SELECT id INTO v_company_id 
        FROM public.companies 
        WHERE v_normalized_phone = ANY(
            SELECT normalize_phone(unnest(phone))
            WHERE phone IS NOT NULL AND phone != '{}'
        ) OR normalize_phone(primary_phone) = v_normalized_phone;
    END IF;

    IF v_company_id IS NOT NULL THEN
        -- Company exists, so update it by merging data
        UPDATE public.companies
        SET
            -- Update primary email if not set
            primary_email = CASE
                WHEN (primary_email IS NULL OR primary_email = '') AND p_email IS NOT NULL AND p_email != '' 
                THEN p_email
                ELSE primary_email
            END,
            -- Add to email array if not already present
            email = CASE
                WHEN p_email IS NULL OR p_email = '' OR normalize_email(p_email) = ANY(
                    SELECT normalize_email(unnest(email)) 
                    UNION 
                    SELECT normalize_email(primary_email)
                ) THEN email
                ELSE array_append(email, p_email)
            END,
            -- Update primary phone if not set
            primary_phone = CASE
                WHEN (primary_phone IS NULL OR primary_phone = '') AND p_phone IS NOT NULL AND p_phone != ''
                THEN p_phone
                ELSE primary_phone
            END,
            -- Add to phone array if not already present
            phone = CASE
                WHEN p_phone IS NULL OR p_phone = '' OR normalize_phone(p_phone) = ANY(
                    SELECT normalize_phone(unnest(phone))
                    UNION
                    SELECT normalize_phone(primary_phone)
                ) THEN phone
                ELSE array_append(phone, p_phone)
            END,
            -- Merge industry arrays and remove duplicates
            industry = (
                SELECT array_agg(DISTINCT industry_item)
                FROM (
                    SELECT unnest(industry) AS industry_item
                    UNION
                    SELECT unnest(p_industry) AS industry_item
                ) combined_industries
                WHERE industry_item IS NOT NULL AND industry_item != ''
            ),
            -- Add city if not already present
            city = CASE
                WHEN p_city IS NULL OR p_city = '' OR p_city = city THEN city
                ELSE p_city
            END,
            -- Add state if not already present  
            state = CASE
                WHEN p_state IS NULL OR p_state = '' OR p_state = state THEN state
                ELSE p_state
            END,
            updated_at = NOW()
        WHERE id = v_company_id;
    ELSE
        -- Company does not exist, so insert a new one
        INSERT INTO public.companies (name, primary_email, email, primary_phone, phone, industry, city, state, status, "group")
        VALUES (
            p_name, 
            CASE WHEN p_email IS NOT NULL AND p_email != '' THEN p_email ELSE '' END,
            CASE WHEN p_email IS NOT NULL AND p_email != '' THEN ARRAY[p_email] ELSE '{}' END,
            CASE WHEN p_phone IS NOT NULL AND p_phone != '' THEN p_phone ELSE '' END,
            CASE WHEN p_phone IS NOT NULL AND p_phone != '' THEN ARRAY[p_phone] ELSE '{}' END,
            COALESCE(p_industry, '{}'),
            COALESCE(p_city, ''),
            COALESCE(p_state, ''),
            'enriching',
            'new'
        ) RETURNING id INTO v_company_id;
    END IF;
    
    RETURN v_company_id;
END;
$$;


ALTER FUNCTION private.upsert_company(p_name text, p_email text, p_phone text, p_industry text[], p_city text, p_state text) OWNER TO postgres;

--
-- Name: insertimg(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insertimg() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_catalog'
    AS $$
begin
  INSERT INTO public."vehicle-photos" (name)
  VALUES (NEW.name);
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.insertimg() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) OWNER TO supabase_admin;

--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO supabase_admin;

--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO supabase_admin;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO supabase_admin;

--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO supabase_admin;

--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO supabase_admin;

--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  BEGIN
    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (payload, event, topic, private, extension)
    VALUES (payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      PERFORM pg_notify(
          'realtime:system',
          jsonb_build_object(
              'error', SQLERRM,
              'function', 'realtime.send',
              'event', event,
              'topic', topic,
              'private', private
          )::text
      );
  END;
END;
$$;


ALTER FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) OWNER TO supabase_admin;

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO supabase_admin;

--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO supabase_admin;

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO supabase_realtime_admin;

--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
_filename text;
BEGIN
	select string_to_array(name, '/') into _parts;
	select _parts[array_length(_parts,1)] into _filename;
	-- @todo return the last part instead of 2
	return reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[1:array_length(_parts,1)-1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::int) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) OWNER TO supabase_storage_admin;

--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text) OWNER TO supabase_storage_admin;

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO supabase_storage_admin;

--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
  v_order_by text;
  v_sort_order text;
begin
  case
    when sortcolumn = 'name' then
      v_order_by = 'name';
    when sortcolumn = 'updated_at' then
      v_order_by = 'updated_at';
    when sortcolumn = 'created_at' then
      v_order_by = 'created_at';
    when sortcolumn = 'last_accessed_at' then
      v_order_by = 'last_accessed_at';
    else
      v_order_by = 'name';
  end case;

  case
    when sortorder = 'asc' then
      v_sort_order = 'asc';
    when sortorder = 'desc' then
      v_sort_order = 'desc';
    else
      v_sort_order = 'asc';
  end case;

  v_order_by = v_order_by || ' ' || v_sort_order;

  return query execute
    'with folders as (
       select path_tokens[$1] as folder
       from storage.objects
         where objects.name ilike $2 || $3 || ''%''
           and bucket_id = $4
           and array_length(objects.path_tokens, 1) <> $1
       group by folder
       order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

--
-- Name: http_request(); Type: FUNCTION; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE FUNCTION supabase_functions.http_request() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'supabase_functions'
    AS $$
    DECLARE
      request_id bigint;
      payload jsonb;
      url text := TG_ARGV[0]::text;
      method text := TG_ARGV[1]::text;
      headers jsonb DEFAULT '{}'::jsonb;
      params jsonb DEFAULT '{}'::jsonb;
      timeout_ms integer DEFAULT 1000;
    BEGIN
      IF url IS NULL OR url = 'null' THEN
        RAISE EXCEPTION 'url argument is missing';
      END IF;

      IF method IS NULL OR method = 'null' THEN
        RAISE EXCEPTION 'method argument is missing';
      END IF;

      IF TG_ARGV[2] IS NULL OR TG_ARGV[2] = 'null' THEN
        headers = '{"Content-Type": "application/json"}'::jsonb;
      ELSE
        headers = TG_ARGV[2]::jsonb;
      END IF;

      IF TG_ARGV[3] IS NULL OR TG_ARGV[3] = 'null' THEN
        params = '{}'::jsonb;
      ELSE
        params = TG_ARGV[3]::jsonb;
      END IF;

      IF TG_ARGV[4] IS NULL OR TG_ARGV[4] = 'null' THEN
        timeout_ms = 1000;
      ELSE
        timeout_ms = TG_ARGV[4]::integer;
      END IF;

      CASE
        WHEN method = 'GET' THEN
          SELECT http_get INTO request_id FROM net.http_get(
            url,
            params,
            headers,
            timeout_ms
          );
        WHEN method = 'POST' THEN
          payload = jsonb_build_object(
            'old_record', OLD,
            'record', NEW,
            'type', TG_OP,
            'table', TG_TABLE_NAME,
            'schema', TG_TABLE_SCHEMA
          );

          SELECT http_post INTO request_id FROM net.http_post(
            url,
            payload,
            params,
            headers,
            timeout_ms
          );
        ELSE
          RAISE EXCEPTION 'method argument % is invalid', method;
      END CASE;

      INSERT INTO supabase_functions.hooks
        (hook_table_id, hook_name, request_id)
      VALUES
        (TG_RELID, TG_NAME, request_id);

      RETURN NEW;
    END
  $$;


ALTER FUNCTION supabase_functions.http_request() OWNER TO supabase_functions_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    industry text[] DEFAULT '{}'::text[],
    primary_email text DEFAULT ''::text,
    email text[] DEFAULT '{}'::text[],
    primary_phone text DEFAULT ''::text,
    phone text[] DEFAULT '{}'::text[],
    city text DEFAULT ''::text,
    state text DEFAULT ''::text,
    status text DEFAULT 'enriching'::text,
    email_message text,
    text_message text,
    "group" text DEFAULT 'new'::text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: contacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contacts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    name text,
    title text,
    email text,
    phone text,
    message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.contacts OWNER TO postgres;

--
-- Name: debug_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.debug_logs (
    id integer NOT NULL,
    message text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.debug_logs OWNER TO postgres;

--
-- Name: debug_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.debug_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.debug_logs_id_seq OWNER TO postgres;

--
-- Name: debug_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.debug_logs_id_seq OWNED BY public.debug_logs.id;


--
-- Name: vehicle-photos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."vehicle-photos" (
    id bigint NOT NULL,
    name text,
    status text DEFAULT 'unprocessed'::text,
    created_at timestamp with time zone DEFAULT now(),
    company_id uuid
);


ALTER TABLE public."vehicle-photos" OWNER TO postgres;

--
-- Name: vehicle-photos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."vehicle-photos" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."vehicle-photos_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


ALTER TABLE realtime.messages OWNER TO supabase_realtime_admin;

--
-- Name: messages_2025_06_24; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_06_24 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_06_24 OWNER TO supabase_admin;

--
-- Name: messages_2025_06_25; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_06_25 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_06_25 OWNER TO supabase_admin;

--
-- Name: messages_2025_06_26; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_06_26 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_06_26 OWNER TO supabase_admin;

--
-- Name: messages_2025_06_27; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_06_27 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_06_27 OWNER TO supabase_admin;

--
-- Name: messages_2025_06_28; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_06_28 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_06_28 OWNER TO supabase_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE realtime.schema_migrations OWNER TO supabase_admin;

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


ALTER TABLE realtime.subscription OWNER TO supabase_admin;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO supabase_storage_admin;

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO supabase_storage_admin;

--
-- Name: hooks; Type: TABLE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE TABLE supabase_functions.hooks (
    id bigint NOT NULL,
    hook_table_id integer NOT NULL,
    hook_name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    request_id bigint
);


ALTER TABLE supabase_functions.hooks OWNER TO supabase_functions_admin;

--
-- Name: TABLE hooks; Type: COMMENT; Schema: supabase_functions; Owner: supabase_functions_admin
--

COMMENT ON TABLE supabase_functions.hooks IS 'Supabase Functions Hooks: Audit trail for triggered hooks.';


--
-- Name: hooks_id_seq; Type: SEQUENCE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE SEQUENCE supabase_functions.hooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE supabase_functions.hooks_id_seq OWNER TO supabase_functions_admin;

--
-- Name: hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER SEQUENCE supabase_functions.hooks_id_seq OWNED BY supabase_functions.hooks.id;


--
-- Name: migrations; Type: TABLE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE TABLE supabase_functions.migrations (
    version text NOT NULL,
    inserted_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE supabase_functions.migrations OWNER TO supabase_functions_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: supabase_migrations; Owner: postgres
--

CREATE TABLE supabase_migrations.schema_migrations (
    version text NOT NULL,
    statements text[],
    name text
);


ALTER TABLE supabase_migrations.schema_migrations OWNER TO postgres;

--
-- Name: seed_files; Type: TABLE; Schema: supabase_migrations; Owner: postgres
--

CREATE TABLE supabase_migrations.seed_files (
    path text NOT NULL,
    hash text NOT NULL
);


ALTER TABLE supabase_migrations.seed_files OWNER TO postgres;

--
-- Name: messages_2025_06_24; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_06_24 FOR VALUES FROM ('2025-06-24 00:00:00') TO ('2025-06-25 00:00:00');


--
-- Name: messages_2025_06_25; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_06_25 FOR VALUES FROM ('2025-06-25 00:00:00') TO ('2025-06-26 00:00:00');


--
-- Name: messages_2025_06_26; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_06_26 FOR VALUES FROM ('2025-06-26 00:00:00') TO ('2025-06-27 00:00:00');


--
-- Name: messages_2025_06_27; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_06_27 FOR VALUES FROM ('2025-06-27 00:00:00') TO ('2025-06-28 00:00:00');


--
-- Name: messages_2025_06_28; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_06_28 FOR VALUES FROM ('2025-06-28 00:00:00') TO ('2025-06-29 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Name: debug_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debug_logs ALTER COLUMN id SET DEFAULT nextval('public.debug_logs_id_seq'::regclass);


--
-- Name: hooks id; Type: DEFAULT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.hooks ALTER COLUMN id SET DEFAULT nextval('supabase_functions.hooks_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
00000000-0000-0000-0000-000000000000	d0147bf8-68d6-4296-b976-03ca0e06c98d	{"action":"user_signedup","actor_id":"00000000-0000-0000-0000-000000000000","actor_username":"service_role","actor_via_sso":false,"log_type":"team","traits":{"user_email":"izzylerman14@gmail.com","user_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","user_phone":""}}	2025-06-25 05:55:01.998673+00	
00000000-0000-0000-0000-000000000000	58dc4289-b17e-4cc7-b821-400f7c0baf42	{"action":"login","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-06-25 05:55:18.957661+00	
00000000-0000-0000-0000-000000000000	17fdc243-3a59-49b1-a135-3b07964d919a	{"action":"login","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-06-25 05:55:20.63247+00	
00000000-0000-0000-0000-000000000000	a1a674b0-b4ad-4655-94a2-25eed09ddcaf	{"action":"login","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-06-25 06:11:47.732408+00	
00000000-0000-0000-0000-000000000000	da73d648-8037-4cb7-a1e9-52d26cfbeebe	{"action":"login","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-06-25 06:12:56.390542+00	
00000000-0000-0000-0000-000000000000	94e9d2cd-6f72-44a3-b817-7c7153fe7c3b	{"action":"login","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-06-25 06:38:04.31378+00	
00000000-0000-0000-0000-000000000000	c6e586c7-a3a8-4b78-844c-b99a01d2fcab	{"action":"login","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-06-25 15:11:49.856733+00	
00000000-0000-0000-0000-000000000000	26f43147-b342-47d5-800b-a80f3eb6df85	{"action":"login","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-06-25 15:11:52.260448+00	
00000000-0000-0000-0000-000000000000	88e4b118-d8ae-4541-9c73-0a33f3547f58	{"action":"login","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-06-25 15:11:53.897024+00	
00000000-0000-0000-0000-000000000000	617ce849-efc7-481c-bb05-7b947de7c5a9	{"action":"login","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-06-25 15:12:03.509734+00	
00000000-0000-0000-0000-000000000000	7356bc6a-634b-4efa-923e-c69f36ad2163	{"action":"login","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-06-25 15:12:08.723043+00	
00000000-0000-0000-0000-000000000000	676a90e1-ad4f-4f5f-a249-64089c157cbf	{"action":"login","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-06-25 16:07:44.424873+00	
00000000-0000-0000-0000-000000000000	9d2faff9-0ecc-43a8-b6ee-da1bcc4e5f9c	{"action":"login","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-06-25 16:09:36.897829+00	
00000000-0000-0000-0000-000000000000	92cb81c6-0d8c-4016-bd62-385c2690bd2d	{"action":"token_refreshed","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"token"}	2025-06-25 16:40:36.065348+00	
00000000-0000-0000-0000-000000000000	bb97175c-5841-476a-9bc8-a0104596636e	{"action":"token_revoked","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"token"}	2025-06-25 16:40:36.067361+00	
00000000-0000-0000-0000-000000000000	c3015d56-1cda-468d-a7bd-53c268783396	{"action":"token_refreshed","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"token"}	2025-06-25 17:08:07.709672+00	
00000000-0000-0000-0000-000000000000	9ca628f0-c160-48ff-92cd-15afe11084dd	{"action":"token_revoked","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"token"}	2025-06-25 17:08:07.710583+00	
00000000-0000-0000-0000-000000000000	4955c69f-4e84-44e4-8632-8662ed579095	{"action":"token_refreshed","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"token"}	2025-06-25 18:06:39.742195+00	
00000000-0000-0000-0000-000000000000	2e0bdfe5-3845-4697-9604-f1e7c5e138f5	{"action":"token_revoked","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"token"}	2025-06-25 18:06:39.74405+00	
00000000-0000-0000-0000-000000000000	7aeb7508-719c-4da7-8926-aeed5e796f0f	{"action":"token_refreshed","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"token"}	2025-06-25 18:10:41.023518+00	
00000000-0000-0000-0000-000000000000	d9eb7933-cabd-45b0-9b55-aeebc54c0a7c	{"action":"token_revoked","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"token"}	2025-06-25 18:10:41.025005+00	
00000000-0000-0000-0000-000000000000	116ce490-d38d-49bb-943e-d7ec679f8e43	{"action":"token_refreshed","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"token"}	2025-06-25 18:19:08.107048+00	
00000000-0000-0000-0000-000000000000	b16f0af8-c03e-4b7e-97e8-aed1f76b0cf6	{"action":"token_revoked","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"token"}	2025-06-25 18:19:08.107941+00	
00000000-0000-0000-0000-000000000000	bfa7716c-6fe5-4af2-8c19-7c545df014d3	{"action":"token_refreshed","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"token"}	2025-06-25 19:06:24.988553+00	
00000000-0000-0000-0000-000000000000	bcd1c137-d978-4e70-80ad-6c0acc6d4917	{"action":"token_revoked","actor_id":"bb7f857e-b36c-4f4b-9944-80e8935ce659","actor_username":"izzylerman14@gmail.com","actor_via_sso":false,"log_type":"token"}	2025-06-25 19:06:24.990153+00	
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
bb7f857e-b36c-4f4b-9944-80e8935ce659	bb7f857e-b36c-4f4b-9944-80e8935ce659	{"sub": "bb7f857e-b36c-4f4b-9944-80e8935ce659", "email": "izzylerman14@gmail.com", "email_verified": false, "phone_verified": false}	email	2025-06-25 05:55:01.996986+00	2025-06-25 05:55:01.997049+00	2025-06-25 05:55:01.997049+00	500891d1-7f94-4b90-9b20-e580a3d8cd9e
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
3627259e-7901-42e0-b755-a60cb450a4a4	2025-06-25 05:55:18.975361+00	2025-06-25 05:55:18.975361+00	password	9414311f-9e03-4024-8165-9318bf3543f2
8b8ac154-478e-4cea-bb1c-61a5a1215609	2025-06-25 05:55:20.635127+00	2025-06-25 05:55:20.635127+00	password	ec74fd41-d852-476f-943f-14cb42f4f7ab
a0154004-9c6d-4731-b2c2-dcd32c59af7a	2025-06-25 06:11:47.745257+00	2025-06-25 06:11:47.745257+00	password	22a013cf-eaf0-459e-9d8a-69768ab819cd
4fb2560b-ca3a-4610-9207-11a324119006	2025-06-25 06:12:56.393316+00	2025-06-25 06:12:56.393316+00	password	d648925a-1cd1-4a9e-8d58-b657bf16dd99
5fef5316-42bc-4594-bf8f-1977b5faa100	2025-06-25 06:38:04.334351+00	2025-06-25 06:38:04.334351+00	password	0d0bb097-d14a-4c63-88fd-27ac0d367131
4ba7e9ed-7785-4eda-b3cf-8bdb91817fde	2025-06-25 15:11:49.928707+00	2025-06-25 15:11:49.928707+00	password	25f1efbd-2f9b-4fcf-bb32-c6b552865fc8
3438ca6d-b8e7-47c4-aed7-19d3d564fc77	2025-06-25 15:11:52.263127+00	2025-06-25 15:11:52.263127+00	password	29a786d6-1124-4ccb-b347-710bbff80a73
7aaedc99-40c3-4146-b608-342395dd29fb	2025-06-25 15:11:53.899646+00	2025-06-25 15:11:53.899646+00	password	0e5517bc-cfdb-4187-80e1-89d350c91824
071f6490-1817-49ea-8537-625f4c1c8eaa	2025-06-25 15:12:03.514683+00	2025-06-25 15:12:03.514683+00	password	8afa86d5-bb38-4f0c-a893-8fbeefeb9180
404303f9-8bea-4991-9b83-713dcd129679	2025-06-25 15:12:08.726205+00	2025-06-25 15:12:08.726205+00	password	2a18b2cf-d6dd-4add-93c7-2b1556495dcc
fce50887-ec18-49da-878b-f970119d19de	2025-06-25 16:07:44.450162+00	2025-06-25 16:07:44.450162+00	password	fa0ca2af-7757-436c-bcd2-b5820002d68f
dfd4710a-d0eb-4190-8219-1a2862ae9029	2025-06-25 16:09:36.905944+00	2025-06-25 16:09:36.905944+00	password	fa49200f-4a4a-4524-b87a-593ef00e23af
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	6	bmz6zourkc7v	bb7f857e-b36c-4f4b-9944-80e8935ce659	f	2025-06-25 05:55:18.964891+00	2025-06-25 05:55:18.964891+00	\N	3627259e-7901-42e0-b755-a60cb450a4a4
00000000-0000-0000-0000-000000000000	7	xgdqerbsgh5q	bb7f857e-b36c-4f4b-9944-80e8935ce659	f	2025-06-25 05:55:20.63393+00	2025-06-25 05:55:20.63393+00	\N	8b8ac154-478e-4cea-bb1c-61a5a1215609
00000000-0000-0000-0000-000000000000	8	rxvd7m3k2vnj	bb7f857e-b36c-4f4b-9944-80e8935ce659	f	2025-06-25 06:11:47.743111+00	2025-06-25 06:11:47.743111+00	\N	a0154004-9c6d-4731-b2c2-dcd32c59af7a
00000000-0000-0000-0000-000000000000	10	t62uann4dmal	bb7f857e-b36c-4f4b-9944-80e8935ce659	f	2025-06-25 06:38:04.32544+00	2025-06-25 06:38:04.32544+00	\N	5fef5316-42bc-4594-bf8f-1977b5faa100
00000000-0000-0000-0000-000000000000	11	wby4px3k3nh7	bb7f857e-b36c-4f4b-9944-80e8935ce659	f	2025-06-25 15:11:49.898384+00	2025-06-25 15:11:49.898384+00	\N	4ba7e9ed-7785-4eda-b3cf-8bdb91817fde
00000000-0000-0000-0000-000000000000	12	vjfax62hhfsa	bb7f857e-b36c-4f4b-9944-80e8935ce659	f	2025-06-25 15:11:52.261951+00	2025-06-25 15:11:52.261951+00	\N	3438ca6d-b8e7-47c4-aed7-19d3d564fc77
00000000-0000-0000-0000-000000000000	13	m2ziyhg7qsw3	bb7f857e-b36c-4f4b-9944-80e8935ce659	f	2025-06-25 15:11:53.898457+00	2025-06-25 15:11:53.898457+00	\N	7aaedc99-40c3-4146-b608-342395dd29fb
00000000-0000-0000-0000-000000000000	14	genrhbdmmszi	bb7f857e-b36c-4f4b-9944-80e8935ce659	f	2025-06-25 15:12:03.513435+00	2025-06-25 15:12:03.513435+00	\N	071f6490-1817-49ea-8537-625f4c1c8eaa
00000000-0000-0000-0000-000000000000	16	kse4wafwwbvq	bb7f857e-b36c-4f4b-9944-80e8935ce659	f	2025-06-25 16:07:44.443399+00	2025-06-25 16:07:44.443399+00	\N	fce50887-ec18-49da-878b-f970119d19de
00000000-0000-0000-0000-000000000000	15	d4i3vukhgfl4	bb7f857e-b36c-4f4b-9944-80e8935ce659	t	2025-06-25 15:12:08.725027+00	2025-06-25 16:40:36.067941+00	\N	404303f9-8bea-4991-9b83-713dcd129679
00000000-0000-0000-0000-000000000000	17	vxj2jowfco2d	bb7f857e-b36c-4f4b-9944-80e8935ce659	t	2025-06-25 16:09:36.903549+00	2025-06-25 17:08:07.711137+00	\N	dfd4710a-d0eb-4190-8219-1a2862ae9029
00000000-0000-0000-0000-000000000000	19	dn6yke7cwhgu	bb7f857e-b36c-4f4b-9944-80e8935ce659	t	2025-06-25 17:08:07.713002+00	2025-06-25 18:06:39.744633+00	vxj2jowfco2d	dfd4710a-d0eb-4190-8219-1a2862ae9029
00000000-0000-0000-0000-000000000000	18	25ldfxpjzexw	bb7f857e-b36c-4f4b-9944-80e8935ce659	t	2025-06-25 16:40:36.073438+00	2025-06-25 18:10:41.025551+00	d4i3vukhgfl4	404303f9-8bea-4991-9b83-713dcd129679
00000000-0000-0000-0000-000000000000	21	ifm7hvdirvv5	bb7f857e-b36c-4f4b-9944-80e8935ce659	f	2025-06-25 18:10:41.026185+00	2025-06-25 18:10:41.026185+00	25ldfxpjzexw	404303f9-8bea-4991-9b83-713dcd129679
00000000-0000-0000-0000-000000000000	9	34y4btigg3ja	bb7f857e-b36c-4f4b-9944-80e8935ce659	t	2025-06-25 06:12:56.392059+00	2025-06-25 18:19:08.108507+00	\N	4fb2560b-ca3a-4610-9207-11a324119006
00000000-0000-0000-0000-000000000000	22	74sdjm5zyspk	bb7f857e-b36c-4f4b-9944-80e8935ce659	f	2025-06-25 18:19:08.109719+00	2025-06-25 18:19:08.109719+00	34y4btigg3ja	4fb2560b-ca3a-4610-9207-11a324119006
00000000-0000-0000-0000-000000000000	20	3f5a3psdmvds	bb7f857e-b36c-4f4b-9944-80e8935ce659	t	2025-06-25 18:06:39.745273+00	2025-06-25 19:06:24.990729+00	dn6yke7cwhgu	dfd4710a-d0eb-4190-8219-1a2862ae9029
00000000-0000-0000-0000-000000000000	23	bfblw4vgq3wr	bb7f857e-b36c-4f4b-9944-80e8935ce659	f	2025-06-25 19:06:24.992718+00	2025-06-25 19:06:24.992718+00	3f5a3psdmvds	dfd4710a-d0eb-4190-8219-1a2862ae9029
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag) FROM stdin;
3627259e-7901-42e0-b755-a60cb450a4a4	bb7f857e-b36c-4f4b-9944-80e8935ce659	2025-06-25 05:55:18.960621+00	2025-06-25 05:55:18.960621+00	\N	aal1	\N	\N	node	54.198.124.21	\N
8b8ac154-478e-4cea-bb1c-61a5a1215609	bb7f857e-b36c-4f4b-9944-80e8935ce659	2025-06-25 05:55:20.633216+00	2025-06-25 05:55:20.633216+00	\N	aal1	\N	\N	node	54.198.124.21	\N
a0154004-9c6d-4731-b2c2-dcd32c59af7a	bb7f857e-b36c-4f4b-9944-80e8935ce659	2025-06-25 06:11:47.740503+00	2025-06-25 06:11:47.740503+00	\N	aal1	\N	\N	node	34.234.76.207	\N
5fef5316-42bc-4594-bf8f-1977b5faa100	bb7f857e-b36c-4f4b-9944-80e8935ce659	2025-06-25 06:38:04.323326+00	2025-06-25 06:38:04.323326+00	\N	aal1	\N	\N	node	3.237.44.194	\N
4ba7e9ed-7785-4eda-b3cf-8bdb91817fde	bb7f857e-b36c-4f4b-9944-80e8935ce659	2025-06-25 15:11:49.878168+00	2025-06-25 15:11:49.878168+00	\N	aal1	\N	\N	node	3.238.14.36	\N
3438ca6d-b8e7-47c4-aed7-19d3d564fc77	bb7f857e-b36c-4f4b-9944-80e8935ce659	2025-06-25 15:11:52.261247+00	2025-06-25 15:11:52.261247+00	\N	aal1	\N	\N	node	3.238.14.36	\N
7aaedc99-40c3-4146-b608-342395dd29fb	bb7f857e-b36c-4f4b-9944-80e8935ce659	2025-06-25 15:11:53.897769+00	2025-06-25 15:11:53.897769+00	\N	aal1	\N	\N	node	3.238.14.36	\N
071f6490-1817-49ea-8537-625f4c1c8eaa	bb7f857e-b36c-4f4b-9944-80e8935ce659	2025-06-25 15:12:03.512577+00	2025-06-25 15:12:03.512577+00	\N	aal1	\N	\N	node	34.202.162.12	\N
fce50887-ec18-49da-878b-f970119d19de	bb7f857e-b36c-4f4b-9944-80e8935ce659	2025-06-25 16:07:44.436742+00	2025-06-25 16:07:44.436742+00	\N	aal1	\N	\N	node	3.83.88.94	\N
404303f9-8bea-4991-9b83-713dcd129679	bb7f857e-b36c-4f4b-9944-80e8935ce659	2025-06-25 15:12:08.723817+00	2025-06-25 18:10:41.029411+00	\N	aal1	\N	2025-06-25 18:10:41.029343	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36 Edg/137.0.0.0	24.190.85.9	\N
4fb2560b-ca3a-4610-9207-11a324119006	bb7f857e-b36c-4f4b-9944-80e8935ce659	2025-06-25 06:12:56.391333+00	2025-06-25 18:19:08.112861+00	\N	aal1	\N	2025-06-25 18:19:08.112791	Vercel Edge Functions	34.206.1.249	\N
dfd4710a-d0eb-4190-8219-1a2862ae9029	bb7f857e-b36c-4f4b-9944-80e8935ce659	2025-06-25 16:09:36.898884+00	2025-06-25 19:06:24.995955+00	\N	aal1	\N	2025-06-25 19:06:24.995887	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15	104.28.39.96	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
00000000-0000-0000-0000-000000000000	bb7f857e-b36c-4f4b-9944-80e8935ce659	authenticated	authenticated	izzylerman14@gmail.com	$2a$10$p9LElfKKMWkYunoSamL13u1M5APnytu4Qwf0zxXFBaN32aYy.iEGu	2025-06-25 05:55:02.000816+00	\N		\N		\N			\N	2025-06-25 16:09:36.898808+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2025-06-25 05:55:01.97951+00	2025-06-25 19:06:24.993857+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (id, name, industry, primary_email, email, primary_phone, phone, city, state, status, email_message, text_message, "group", created_at, updated_at) FROM stdin;
92bedd3a-991a-4ed7-8bb1-f6ba8c0b24cd	Moller Mechanical Services Inc.	{"air conditioning",refrigeration,"sheet metal",heating,ventilation}		{}	9739624339	{9739624339}	Ringwood	NJ	enriching	\N	\N	new	2025-06-25 06:01:50.107764+00	2025-06-25 06:01:50.107764+00
9522cbc9-4e58-40c7-9ded-87440bf1e195	Weiner Whackers LLC	{"Whackin it"}		{}		{}	Meyerville		enriching	\N	\N	new	2025-06-25 06:12:30.918421+00	2025-06-25 06:12:30.918421+00
6f3c17dd-e528-4cde-9432-31113da95e52	Katham Industries	{heating,"air conditioning",generators,"duct cleaning"}		{}	2015697192	{2015697192}		NJ	enriching	\N	\N	new	2025-06-25 16:12:29.99415+00	2025-06-25 16:12:29.99415+00
4893011a-8bcd-47a9-8df9-24660d2974af	Doke's Plumbing Inc.	{plumbing,heating,cooling,"fire protection"}		{}	4154537508	{4154537508}			enriching	\N	\N	new	2025-06-25 16:41:09.01819+00	2025-06-25 16:41:09.01819+00
e8ff86aa-1614-4daf-9ce3-5d690aae3bc7	Spartan Action Plumbing	{plumbing}		{}	8002284224	{8002284224}		New Jersey	enriching	\N	\N	new	2025-06-25 16:41:12.947738+00	2025-06-25 16:41:12.947738+00
6ae30aaf-3823-4d62-91e0-69cc1d60acdf	Fletcher's	{"air conditioning","Air Conditioning","drain cleaning","Drain Cleaning",heating,Heating,plumbing,Plumbing,"water treatment","Water Treatment","well pumps","Well Pumps"}		{}	8605824643	{8605824643}	Bristol		enriching	\N	\N	new	2025-06-25 05:56:03.638394+00	2025-06-25 16:41:23.025224+00
ac48f456-f4dd-445f-a7af-5da18915d8f9	Horizon Services	{plumbing,heating,"air conditioning","drain cleaning","water treatment",electrical}		{}	6093266500	{6093266500}			enriching	\N	\N	new	2025-06-25 16:41:26.792876+00	2025-06-25 16:41:26.792876+00
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contacts (id, company_id, name, title, email, phone, message, created_at, updated_at) FROM stdin;
a671bb98-5b10-45c0-9913-708995bdcadc	9522cbc9-4e58-40c7-9ded-87440bf1e195	Eric Seifert	whacking strategist	\N	\N	\N	2025-06-25 06:45:14.549059+00	2025-06-25 06:45:14.549059+00
\.


--
-- Data for Name: debug_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.debug_logs (id, message, created_at) FROM stdin;
1	[check_queue_size_and_trigger()] queue size: 1	2025-06-25 05:55:57.304987
2	[check_queue_size_and_trigger()] Making HTTP POST to: https://jtjilaxinqzjlqssegad.supabase.co/functions/v1/worker	2025-06-25 05:55:57.304987
3	[check_queue_size_and_trigger()] HTTP request submitted, ID: 27	2025-06-25 05:55:57.304987
4	[check_queue_size_and_trigger()] No response found for request ID: 27	2025-06-25 05:55:57.304987
5	[check_queue_size_and_trigger()] Checking all responses in table...	2025-06-25 05:55:57.304987
6	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 05:55:57.304987
7	[check_queue_size_and_trigger()] Recent response - Status: 500, Body: {"error":"Failed to create signed URL for world: Object not found"}	2025-06-25 05:55:57.304987
8	[check_queue_size_and_trigger()] Recent response - Status: 500, Body: {"error":"Failed to create signed URL for world: Object not found"}	2025-06-25 05:55:57.304987
9	[check_queue_size_and_trigger()] Response Status: 500	2025-06-25 05:55:57.304987
10	[check_queue_size_and_trigger()] Response Body: {"error":"Failed to create signed URL for world: Object not found"}	2025-06-25 05:55:57.304987
11	[check_queue_size_and_trigger()] Response Headers: NULL	2025-06-25 05:55:57.304987
12	[check_queue_size_and_trigger()] queue size: 1	2025-06-25 06:01:43.959159
13	[check_queue_size_and_trigger()] Making HTTP POST to: https://jtjilaxinqzjlqssegad.supabase.co/functions/v1/worker	2025-06-25 06:01:43.959159
14	[check_queue_size_and_trigger()] HTTP request submitted, ID: 28	2025-06-25 06:01:43.959159
15	[check_queue_size_and_trigger()] No response found for request ID: 28	2025-06-25 06:01:43.959159
16	[check_queue_size_and_trigger()] Checking all responses in table...	2025-06-25 06:01:43.959159
17	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 06:01:43.959159
18	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 06:01:43.959159
19	[check_queue_size_and_trigger()] Recent response - Status: 500, Body: {"error":"Failed to create signed URL for world: Object not found"}	2025-06-25 06:01:43.959159
20	[check_queue_size_and_trigger()] Response Status: 500	2025-06-25 06:01:43.959159
21	[check_queue_size_and_trigger()] Response Body: {"error":"Failed to create signed URL for world: Object not found"}	2025-06-25 06:01:43.959159
22	[check_queue_size_and_trigger()] Response Headers: NULL	2025-06-25 06:01:43.959159
23	[check_queue_size_and_trigger()] queue size: 1	2025-06-25 16:12:22.587862
24	[check_queue_size_and_trigger()] Making HTTP POST to: https://jtjilaxinqzjlqssegad.supabase.co/functions/v1/worker	2025-06-25 16:12:22.587862
25	[check_queue_size_and_trigger()] HTTP request submitted, ID: 29	2025-06-25 16:12:22.587862
26	[check_queue_size_and_trigger()] No response found for request ID: 29	2025-06-25 16:12:22.587862
27	[check_queue_size_and_trigger()] Checking all responses in table...	2025-06-25 16:12:22.587862
28	[check_queue_size_and_trigger()] Response Status: NULL	2025-06-25 16:12:22.587862
29	[check_queue_size_and_trigger()] Response Body: NULL	2025-06-25 16:12:22.587862
30	[check_queue_size_and_trigger()] Response Headers: NULL	2025-06-25 16:12:22.587862
31	[check_queue_size_and_trigger()] queue size: 1	2025-06-25 16:41:01.042064
32	[check_queue_size_and_trigger()] Making HTTP POST to: https://jtjilaxinqzjlqssegad.supabase.co/functions/v1/worker	2025-06-25 16:41:01.042064
33	[check_queue_size_and_trigger()] HTTP request submitted, ID: 30	2025-06-25 16:41:01.042064
34	[check_queue_size_and_trigger()] No response found for request ID: 30	2025-06-25 16:41:01.042064
35	[check_queue_size_and_trigger()] Checking all responses in table...	2025-06-25 16:41:01.042064
36	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 16:41:01.042064
37	[check_queue_size_and_trigger()] Response Status: 200	2025-06-25 16:41:01.042064
38	[check_queue_size_and_trigger()] Response Body: {"message":"Processed images successfully"}	2025-06-25 16:41:01.042064
39	[check_queue_size_and_trigger()] Response Headers: NULL	2025-06-25 16:41:01.042064
40	[check_queue_size_and_trigger()] queue size: 2	2025-06-25 16:41:06.694972
41	[check_queue_size_and_trigger()] Making HTTP POST to: https://jtjilaxinqzjlqssegad.supabase.co/functions/v1/worker	2025-06-25 16:41:06.694972
42	[check_queue_size_and_trigger()] HTTP request submitted, ID: 31	2025-06-25 16:41:06.694972
43	[check_queue_size_and_trigger()] No response found for request ID: 31	2025-06-25 16:41:06.694972
44	[check_queue_size_and_trigger()] Checking all responses in table...	2025-06-25 16:41:06.694972
45	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 16:41:06.694972
46	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 16:41:06.694972
47	[check_queue_size_and_trigger()] Response Status: 200	2025-06-25 16:41:06.694972
48	[check_queue_size_and_trigger()] Response Body: {"message":"Processed images successfully"}	2025-06-25 16:41:06.694972
49	[check_queue_size_and_trigger()] Response Headers: NULL	2025-06-25 16:41:06.694972
50	[check_queue_size_and_trigger()] queue size: 2	2025-06-25 16:41:12.394469
51	[check_queue_size_and_trigger()] Making HTTP POST to: https://jtjilaxinqzjlqssegad.supabase.co/functions/v1/worker	2025-06-25 16:41:12.394469
52	[check_queue_size_and_trigger()] HTTP request submitted, ID: 32	2025-06-25 16:41:12.394469
53	[check_queue_size_and_trigger()] No response found for request ID: 32	2025-06-25 16:41:12.394469
54	[check_queue_size_and_trigger()] Checking all responses in table...	2025-06-25 16:41:12.394469
55	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 16:41:12.394469
56	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 16:41:12.394469
57	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 16:41:12.394469
58	[check_queue_size_and_trigger()] Response Status: 200	2025-06-25 16:41:12.394469
59	[check_queue_size_and_trigger()] Response Body: {"message":"Processed images successfully"}	2025-06-25 16:41:12.394469
60	[check_queue_size_and_trigger()] Response Headers: NULL	2025-06-25 16:41:12.394469
61	[check_queue_size_and_trigger()] queue size: 2	2025-06-25 16:41:15.759114
62	[check_queue_size_and_trigger()] Making HTTP POST to: https://jtjilaxinqzjlqssegad.supabase.co/functions/v1/worker	2025-06-25 16:41:15.759114
63	[check_queue_size_and_trigger()] HTTP request submitted, ID: 33	2025-06-25 16:41:15.759114
64	[check_queue_size_and_trigger()] No response found for request ID: 33	2025-06-25 16:41:15.759114
65	[check_queue_size_and_trigger()] Checking all responses in table...	2025-06-25 16:41:15.759114
66	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 16:41:15.759114
67	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 16:41:15.759114
68	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 16:41:15.759114
69	[check_queue_size_and_trigger()] Response Status: 200	2025-06-25 16:41:15.759114
70	[check_queue_size_and_trigger()] Response Body: {"message":"Processed images successfully"}	2025-06-25 16:41:15.759114
71	[check_queue_size_and_trigger()] Response Headers: NULL	2025-06-25 16:41:15.759114
72	[check_queue_size_and_trigger()] queue size: 2	2025-06-25 16:41:19.067935
73	[check_queue_size_and_trigger()] Making HTTP POST to: https://jtjilaxinqzjlqssegad.supabase.co/functions/v1/worker	2025-06-25 16:41:19.067935
74	[check_queue_size_and_trigger()] HTTP request submitted, ID: 34	2025-06-25 16:41:19.067935
75	[check_queue_size_and_trigger()] No response found for request ID: 34	2025-06-25 16:41:19.067935
76	[check_queue_size_and_trigger()] Checking all responses in table...	2025-06-25 16:41:19.067935
77	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 16:41:19.067935
78	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 16:41:19.067935
79	[check_queue_size_and_trigger()] Recent response - Status: 200, Body: {"message":"Processed images successfully"}	2025-06-25 16:41:19.067935
80	[check_queue_size_and_trigger()] Response Status: 200	2025-06-25 16:41:19.067935
81	[check_queue_size_and_trigger()] Response Body: {"message":"Processed images successfully"}	2025-06-25 16:41:19.067935
82	[check_queue_size_and_trigger()] Response Headers: NULL	2025-06-25 16:41:19.067935
\.


--
-- Data for Name: vehicle-photos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."vehicle-photos" (id, name, status, created_at, company_id) FROM stdin;
4	uploads/vehicle_e92e3187-1cc5-4fe4-80af-be90062f1e36.JPG	unprocessed	2025-06-25 06:01:43.85142+00	92bedd3a-991a-4ed7-8bb1-f6ba8c0b24cd
6	uploads/seif_weiner_pic.jpeg	unprocessed	2025-06-25 06:35:28.445731+00	9522cbc9-4e58-40c7-9ded-87440bf1e195
8	uploads/vehicle_b079336b-f1f0-411a-9f9d-dcf5a02a0716.JPG	unprocessed	2025-06-25 16:12:22.46483+00	6f3c17dd-e528-4cde-9432-31113da95e52
10	uploads/vehicle_40fb8839-5a2c-4f55-9deb-b91a1382e81d.jpg	unprocessed	2025-06-25 16:41:00.958388+00	4893011a-8bcd-47a9-8df9-24660d2974af
12	uploads/vehicle_cd2fe167-007a-47e8-ad16-2d05e5c8eb3d.jpg	unprocessed	2025-06-25 16:41:06.618834+00	e8ff86aa-1614-4daf-9ce3-5d690aae3bc7
14	uploads/vehicle_effd68f9-95cf-4ffe-99b0-f45bdc8a12ef.jpg	unprocessed	2025-06-25 16:41:12.319176+00	6ae30aaf-3823-4d62-91e0-69cc1d60acdf
16	uploads/vehicle_38ef1745-3f81-4175-9b83-4b8fdcff82e6.JPG	unprocessed	2025-06-25 16:41:15.678928+00	6ae30aaf-3823-4d62-91e0-69cc1d60acdf
18	uploads/vehicle_60e2b5c8-dab4-4352-88de-652eb5010f66.HEIC	unprocessed	2025-06-25 16:41:18.989917+00	ac48f456-f4dd-445f-a7af-5da18915d8f9
\.


--
-- Data for Name: messages_2025_06_24; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_06_24 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: messages_2025_06_25; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_06_25 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: messages_2025_06_26; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_06_26 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: messages_2025_06_27; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_06_27 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: messages_2025_06_28; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_06_28 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2025-06-13 18:58:33
20211116045059	2025-06-13 18:58:35
20211116050929	2025-06-13 18:58:38
20211116051442	2025-06-13 18:58:40
20211116212300	2025-06-13 18:58:42
20211116213355	2025-06-13 18:58:44
20211116213934	2025-06-13 18:58:46
20211116214523	2025-06-13 18:58:49
20211122062447	2025-06-13 18:58:51
20211124070109	2025-06-13 18:58:53
20211202204204	2025-06-13 18:58:55
20211202204605	2025-06-13 18:58:57
20211210212804	2025-06-13 18:59:03
20211228014915	2025-06-13 18:59:05
20220107221237	2025-06-13 18:59:07
20220228202821	2025-06-13 18:59:09
20220312004840	2025-06-13 18:59:11
20220603231003	2025-06-13 18:59:15
20220603232444	2025-06-13 18:59:17
20220615214548	2025-06-13 18:59:19
20220712093339	2025-06-13 18:59:21
20220908172859	2025-06-13 18:59:23
20220916233421	2025-06-13 18:59:25
20230119133233	2025-06-13 18:59:27
20230128025114	2025-06-13 18:59:30
20230128025212	2025-06-13 18:59:32
20230227211149	2025-06-13 18:59:34
20230228184745	2025-06-13 18:59:36
20230308225145	2025-06-13 18:59:38
20230328144023	2025-06-13 18:59:40
20231018144023	2025-06-13 18:59:42
20231204144023	2025-06-13 18:59:46
20231204144024	2025-06-13 18:59:48
20231204144025	2025-06-13 18:59:50
20240108234812	2025-06-13 18:59:52
20240109165339	2025-06-13 18:59:54
20240227174441	2025-06-13 18:59:57
20240311171622	2025-06-13 19:00:00
20240321100241	2025-06-13 19:00:04
20240401105812	2025-06-13 19:00:10
20240418121054	2025-06-13 19:00:13
20240523004032	2025-06-13 19:00:20
20240618124746	2025-06-13 19:00:22
20240801235015	2025-06-13 19:00:24
20240805133720	2025-06-13 19:00:26
20240827160934	2025-06-13 19:00:28
20240919163303	2025-06-13 19:00:31
20240919163305	2025-06-13 19:00:33
20241019105805	2025-06-13 19:00:35
20241030150047	2025-06-13 19:00:43
20241108114728	2025-06-13 19:00:45
20241121104152	2025-06-13 19:00:47
20241130184212	2025-06-13 19:00:50
20241220035512	2025-06-13 19:00:52
20241220123912	2025-06-13 19:00:54
20241224161212	2025-06-13 19:00:56
20250107150512	2025-06-13 19:00:58
20250110162412	2025-06-13 19:01:00
20250123174212	2025-06-13 19:01:02
20250128220012	2025-06-13 19:01:04
20250506224012	2025-06-13 19:01:05
20250523164012	2025-06-13 19:01:07
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id) FROM stdin;
gh-vehicle-photos	gh-vehicle-photos	\N	2025-06-22 17:02:59.30071+00	2025-06-22 17:02:59.30071+00	f	f	10000000	{image/*}	\N
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2025-06-13 18:58:29.141171
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2025-06-13 18:58:29.153815
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2025-06-13 18:58:29.156729
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2025-06-13 18:58:29.185402
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2025-06-13 18:58:29.213938
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2025-06-13 18:58:29.218393
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2025-06-13 18:58:29.222242
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2025-06-13 18:58:29.225864
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2025-06-13 18:58:29.230827
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2025-06-13 18:58:29.234416
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2025-06-13 18:58:29.239476
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2025-06-13 18:58:29.244674
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2025-06-13 18:58:29.250589
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2025-06-13 18:58:29.253924
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2025-06-13 18:58:29.257298
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2025-06-13 18:58:29.287898
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2025-06-13 18:58:29.291801
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2025-06-13 18:58:29.295633
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2025-06-13 18:58:29.299488
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2025-06-13 18:58:29.304556
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2025-06-13 18:58:29.309237
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2025-06-13 18:58:29.318155
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2025-06-13 18:58:29.35178
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2025-06-13 18:58:29.377317
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2025-06-13 18:58:29.381031
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2025-06-13 18:58:29.384662
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
3d1bc053-c50d-4021-aa2f-e4b444b93765	gh-vehicle-photos	uploads/vehicle_e92e3187-1cc5-4fe4-80af-be90062f1e36.JPG	\N	2025-06-25 06:01:43.85142+00	2025-06-25 06:01:43.85142+00	2025-06-25 06:01:43.85142+00	{"eTag": "\\"24121f659dbbd70394df2d02b673984c\\"", "size": 622556, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2025-06-25T06:01:44.000Z", "contentLength": 622556, "httpStatusCode": 200}	5954bb78-9879-4f26-945c-f8c842372f55	\N	{}
5481d4d8-50c0-4488-8b64-5158f5893e9d	gh-vehicle-photos	uploads/seif_weiner_pic.jpeg	\N	2025-06-25 06:35:28.445731+00	2025-06-25 06:36:18.152344+00	2025-06-25 06:35:28.445731+00	{"eTag": "\\"570a5e793d54c70db3f5473a93c9f540\\"", "size": 960193, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2025-06-25T06:36:18.000Z", "contentLength": 960193, "httpStatusCode": 200}	e93549dc-172a-4a61-beae-a4b747f36166	\N	\N
9cccd6d8-6875-4f1b-82ed-feea5ed46b0f	gh-vehicle-photos	uploads/vehicle_b079336b-f1f0-411a-9f9d-dcf5a02a0716.JPG	\N	2025-06-25 16:12:22.46483+00	2025-06-25 16:12:22.46483+00	2025-06-25 16:12:22.46483+00	{"eTag": "\\"ca718db3a28e14861c2f375dced3ed7b\\"", "size": 834007, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2025-06-25T16:12:23.000Z", "contentLength": 834007, "httpStatusCode": 200}	ffbf9227-3f8f-48fc-a0c7-5644ae5b6eb2	\N	{}
cc70c7f3-18af-4d2d-b1b4-66aabdbdf926	gh-vehicle-photos	uploads/vehicle_40fb8839-5a2c-4f55-9deb-b91a1382e81d.jpg	\N	2025-06-25 16:41:00.958388+00	2025-06-25 16:41:00.958388+00	2025-06-25 16:41:00.958388+00	{"eTag": "\\"a8bfb756251af009f1a585fafb38bc94\\"", "size": 62074, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2025-06-25T16:41:01.000Z", "contentLength": 62074, "httpStatusCode": 200}	55ec4a83-a3f3-4517-8fba-8469d9107327	\N	{}
5dcb5786-79c4-4a2d-978f-7fdaec9b2f64	gh-vehicle-photos	uploads/vehicle_cd2fe167-007a-47e8-ad16-2d05e5c8eb3d.jpg	\N	2025-06-25 16:41:06.618834+00	2025-06-25 16:41:06.618834+00	2025-06-25 16:41:06.618834+00	{"eTag": "\\"f8ecdfd3fb5e3d3b61b83cbb9389b0af\\"", "size": 97911, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2025-06-25T16:41:07.000Z", "contentLength": 97911, "httpStatusCode": 200}	ef30f16d-a914-4d37-85ce-cb2d932412ce	\N	{}
9db1cb4a-bb6e-446e-983e-f53f3c9d9f1a	gh-vehicle-photos	uploads/vehicle_effd68f9-95cf-4ffe-99b0-f45bdc8a12ef.jpg	\N	2025-06-25 16:41:12.319176+00	2025-06-25 16:41:12.319176+00	2025-06-25 16:41:12.319176+00	{"eTag": "\\"598c27fb60770a58d36ac6f4f896aade\\"", "size": 69144, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2025-06-25T16:41:13.000Z", "contentLength": 69144, "httpStatusCode": 200}	3c944aae-036d-4606-872a-b90d027672d1	\N	{}
5540a2ff-5358-4773-8ac3-6755afc69ec0	gh-vehicle-photos	uploads/vehicle_38ef1745-3f81-4175-9b83-4b8fdcff82e6.JPG	\N	2025-06-25 16:41:15.678928+00	2025-06-25 16:41:15.678928+00	2025-06-25 16:41:15.678928+00	{"eTag": "\\"1395290e3dddc7a666ecbd0106ecca4a\\"", "size": 541801, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2025-06-25T16:41:16.000Z", "contentLength": 541801, "httpStatusCode": 200}	7450e16d-8a2a-4169-bd1c-75946bf036a8	\N	{}
8a2527a8-364a-4d07-9944-25d249bb8695	gh-vehicle-photos	uploads/vehicle_60e2b5c8-dab4-4352-88de-652eb5010f66.HEIC	\N	2025-06-25 16:41:18.989917+00	2025-06-25 16:41:18.989917+00	2025-06-25 16:41:18.989917+00	{"eTag": "\\"5691a09bac45f6d417ccbfe127da6207\\"", "size": 712292, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2025-06-25T16:41:19.000Z", "contentLength": 712292, "httpStatusCode": 200}	db6316d7-9e05-4eea-86df-c015d37c05cf	\N	{}
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: hooks; Type: TABLE DATA; Schema: supabase_functions; Owner: supabase_functions_admin
--

COPY supabase_functions.hooks (id, hook_table_id, hook_name, created_at, request_id) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: supabase_functions; Owner: supabase_functions_admin
--

COPY supabase_functions.migrations (version, inserted_at) FROM stdin;
initial	2025-06-19 15:24:41.154703+00
20210809183423_update_grants	2025-06-19 15:24:41.154703+00
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: supabase_migrations; Owner: postgres
--

COPY supabase_migrations.schema_migrations (version, statements, name) FROM stdin;
20250522190031	{"CREATE SCHEMA private","revoke usage on SCHEMA private from anon, public","GRANT USAGE ON SCHEMA private TO service_role, authenticated","GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA private TO service_role, authenticated"}	private_schema
20250618212702	{"CREATE TABLE public.\\"vehicle-photos\\" (\n  id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,\n  name TEXT UNIQUE, -- file name from storage\n  status TEXT DEFAULT 'unprocessed', \n  created_at TIMESTAMPTZ DEFAULT NOW(),\n  company_id INTEGER DEFAULT NULL,\n  CONSTRAINT fk_company\n    FOREIGN KEY (company_id) REFERENCES \\"vehicle-photos\\"(id)\n    ON DELETE SET NULL\n\n)","ALTER TABLE public.\\"vehicle-photos\\" ENABLE ROW LEVEL SECURITY","create policy \\"block_all\\"\non \\"public\\".\\"vehicle-photos\\"\nfor ALL\nto public\nusing (false)\nwith check (false)"}	create_vehicle_photos_table
20250618212908	{"CREATE TABLE public.companies (\n id UUID DEFAULT gen_random_uuid() PRIMARY KEY,\n name TEXT NOT NULL,\n industry TEXT[] DEFAULT '{}',\n primary_email TEXT DEFAULT '',\n email TEXT[] DEFAULT '{}',\n primary_phone TEXT DEFAULT '',\n phone TEXT[] DEFAULT '{}',\n city TEXT DEFAULT '',\n state TEXT DEFAULT '',\n status TEXT DEFAULT 'enriching',\n email_message TEXT DEFAULT NULL,\n text_message TEXT DEFAULT NULL,\n \\"group\\" TEXT DEFAULT 'new',\n created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY","create policy \\"block_all\\"\non public.companies\nfor ALL\nto public\nusing (false)\nwith check (false)"}	create_companies_table
20250618213549	{"CREATE OR REPLACE FUNCTION public.insertimg()\nRETURNS trigger\nLANGUAGE plpgsql\nSECURITY INVOKER\nSET search_path = public, pg_catalog AS $$\nbegin\n  INSERT INTO public.\\"vehicle-photos\\" (name)\n  VALUES (NEW.name);\n  RETURN NEW;\nEND;\n$$","CREATE TRIGGER on_new_image\nAFTER INSERT ON storage.objects\nFOR EACH ROW\nWHEN (NEW.bucket_id = 'gh-vehicle-photos') \nEXECUTE PROCEDURE public.insertimg()"}	create_insertimg
20250618213623	{"CREATE extension IF NOT EXISTS pgmq CASCADE","SELECT pgmq.create('image-processing')","-- networking\ncreate extension IF NOT EXISTS pg_net","-- restrictive RLS\nALTER TABLE pgmq.\\"q_image-processing\\" ENABLE ROW LEVEL SECURITY","create policy \\"block_all\\"\non \\"pgmq\\".\\"q_image-processing\\"\nfor ALL\nto public\nusing (false)\nwith check (false)"}	pgmq
20250618213714	{"CREATE OR REPLACE FUNCTION private.normalize_company_name(name_input TEXT)\nRETURNS TEXT AS $$\nBEGIN\n    RETURN LOWER(\n        TRIM(\n            REGEXP_REPLACE(\n                REGEXP_REPLACE(\n                    name_input,\n                    '[^\\\\w\\\\s]', '', 'g'\n                ),\n                '\\\\b(inc|corp|llc|co|ltd|plc)\\\\b', '', 'gi'\n            )\n        )\n    );\nEND;\n$$ LANGUAGE plpgsql IMMUTABLE SECURITY DEFINER SET search_path = private","CREATE OR REPLACE FUNCTION private.normalize_email(email_input TEXT)\nRETURNS TEXT AS $$\nBEGIN\n    RETURN LOWER(TRIM(email_input));\nEND;\n$$ LANGUAGE plpgsql IMMUTABLE SECURITY DEFINER SET search_path = private","CREATE OR REPLACE FUNCTION private.normalize_phone(phone_input TEXT)\nRETURNS TEXT AS $$\nBEGIN\n    RETURN REGEXP_REPLACE(phone_input, '\\\\D', '', 'g');\nEND;\n$$ LANGUAGE plpgsql IMMUTABLE SECURITY DEFINER SET search_path = private","CREATE OR REPLACE FUNCTION private.upsert_company(p_name TEXT, p_email TEXT, p_phone TEXT, p_industry TEXT[], p_city TEXT, p_state TEXT)\nRETURNS UUID AS $$\nDECLARE\n    v_company_id UUID;\n    v_normalized_name TEXT;\n    v_normalized_email TEXT;\n    v_normalized_phone TEXT;\nBEGIN\n    v_normalized_name := normalize_company_name(p_name);\n    v_normalized_email := CASE WHEN p_email IS NOT NULL AND p_email != '' THEN normalize_email(p_email) ELSE NULL END;\n    v_normalized_phone := CASE WHEN p_phone IS NOT NULL AND p_phone != '' THEN normalize_phone(p_phone) ELSE NULL END;\n\n    -- Find existing company with priority: name, email, phone\n    SELECT id INTO v_company_id \n    FROM public.companies \n    WHERE normalize_company_name(name) = v_normalized_name;\n\n    -- If no name match and email provided, check for email match\n    IF v_company_id IS NULL AND v_normalized_email IS NOT NULL THEN\n        SELECT id INTO v_company_id \n        FROM public.companies \n        WHERE v_normalized_email = ANY(\n            SELECT normalize_email(unnest(email))\n            WHERE email IS NOT NULL AND email != '{}'\n        ) OR normalize_email(primary_email) = v_normalized_email;\n    END IF;\n\n    -- If no name/email match and phone provided, check for phone match\n    IF v_company_id IS NULL AND v_normalized_phone IS NOT NULL THEN\n        SELECT id INTO v_company_id \n        FROM public.companies \n        WHERE v_normalized_phone = ANY(\n            SELECT normalize_phone(unnest(phone))\n            WHERE phone IS NOT NULL AND phone != '{}'\n        ) OR normalize_phone(primary_phone) = v_normalized_phone;\n    END IF;\n\n    IF v_company_id IS NOT NULL THEN\n        -- Company exists, so update it by merging data\n        UPDATE public.companies\n        SET\n            -- Update primary email if not set\n            primary_email = CASE\n                WHEN (primary_email IS NULL OR primary_email = '') AND p_email IS NOT NULL AND p_email != '' \n                THEN p_email\n                ELSE primary_email\n            END,\n            -- Add to email array if not already present\n            email = CASE\n                WHEN p_email IS NULL OR p_email = '' OR normalize_email(p_email) = ANY(\n                    SELECT normalize_email(unnest(email)) \n                    UNION \n                    SELECT normalize_email(primary_email)\n                ) THEN email\n                ELSE array_append(email, p_email)\n            END,\n            -- Update primary phone if not set\n            primary_phone = CASE\n                WHEN (primary_phone IS NULL OR primary_phone = '') AND p_phone IS NOT NULL AND p_phone != ''\n                THEN p_phone\n                ELSE primary_phone\n            END,\n            -- Add to phone array if not already present\n            phone = CASE\n                WHEN p_phone IS NULL OR p_phone = '' OR normalize_phone(p_phone) = ANY(\n                    SELECT normalize_phone(unnest(phone))\n                    UNION\n                    SELECT normalize_phone(primary_phone)\n                ) THEN phone\n                ELSE array_append(phone, p_phone)\n            END,\n            -- Merge industry arrays and remove duplicates\n            industry = (\n                SELECT array_agg(DISTINCT industry_item)\n                FROM (\n                    SELECT unnest(industry) AS industry_item\n                    UNION\n                    SELECT unnest(p_industry) AS industry_item\n                ) combined_industries\n                WHERE industry_item IS NOT NULL AND industry_item != ''\n            ),\n            -- Add city if not already present\n            city = CASE\n                WHEN p_city IS NULL OR p_city = '' OR p_city = city THEN city\n                ELSE p_city\n            END,\n            -- Add state if not already present  \n            state = CASE\n                WHEN p_state IS NULL OR p_state = '' OR p_state = state THEN state\n                ELSE p_state\n            END,\n            updated_at = NOW()\n        WHERE id = v_company_id;\n    ELSE\n        -- Company does not exist, so insert a new one\n        INSERT INTO public.companies (name, primary_email, email, primary_phone, phone, industry, city, state, status, \\"group\\")\n        VALUES (\n            p_name, \n            CASE WHEN p_email IS NOT NULL AND p_email != '' THEN p_email ELSE '' END,\n            CASE WHEN p_email IS NOT NULL AND p_email != '' THEN ARRAY[p_email] ELSE '{}' END,\n            CASE WHEN p_phone IS NOT NULL AND p_phone != '' THEN p_phone ELSE '' END,\n            CASE WHEN p_phone IS NOT NULL AND p_phone != '' THEN ARRAY[p_phone] ELSE '{}' END,\n            COALESCE(p_industry, '{}'),\n            COALESCE(p_city, ''),\n            COALESCE(p_state, ''),\n            'enriching',\n            'new'\n        ) RETURNING id INTO v_company_id;\n    END IF;\n    \n    RETURN v_company_id;\nEND;\n$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = private"}	create_upsertcompany
20250618220835	{"insert into storage.buckets \n    (id, name, public, allowed_mime_types, file_size_limit)\nvalues\n    ('gh-vehicle-photos', 'gh-vehicle-photos', false, ARRAY['image/*'], 10000000)\non conflict (id) do nothing","create policy \\"block_all\\"\non storage.objects\nfor ALL\nto public\nusing (false)\nwith check (false)"}	create_vehicle_photos_bucket
20250619154643	{"-- Check q size, if its >=5 then trigger the worker\n\nCREATE OR REPLACE FUNCTION private.check_queue_size_and_trigger()\nRETURNS trigger AS $$\nDECLARE\n  queue_size INTEGER;\n  worker_url TEXT;\n  queue_max INTEGER = 1;\n  worker_timeout_ms INTEGER = 5000;\n  supabase_service_role_key TEXT;\n  auth_token TEXT;\n  http_request_id bigint;\n  response_status INTEGER;\n  response_body TEXT;\n  response_headers jsonb;\nBEGIN\n\n  SELECT count(*) INTO queue_size \n  FROM pgmq.\\"q_image-processing\\";\n\n  insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] queue size: ' || queue_size);\n  \n  IF queue_size >= queue_max THEN\n    worker_url := (select decrypted_secret from vault.decrypted_secrets where name = 'worker_url');\n    supabase_service_role_key := (select decrypted_secret from vault.decrypted_secrets where name = 'supabase_service_role_key');\n\n    if worker_url IS NULL THEN\n      insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] worker_url is NULL');\n    END IF;\n\n    if supabase_service_role_key IS NULL THEN\n      insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] supabase_service_role_key is NULL');\n    END IF;\n\n    auth_token := 'Bearer ' || supabase_service_role_key;\n\n    \n    -- Trigger worker\n    IF worker_url IS NOT NULL THEN\n      insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Making HTTP POST to: ' || worker_url);\n      \n      BEGIN\n        -- Make HTTP request and get the request ID\n        SELECT net.http_post(\n          url:=worker_url,\n          headers:= jsonb_build_object(\n          'Content-Type','application/json',\n          'Authorization', auth_token\n        ),\n          timeout_milliseconds:=worker_timeout_ms\n        ) INTO http_request_id;\n        \n        insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] HTTP request submitted, ID: ' || http_request_id);\n        \n        -- Wait for the request to complete (pg_net is async)\n        PERFORM pg_sleep(3);\n        \n        -- Get the response from net._http_response table (note the underscore)\n        BEGIN\n          SELECT status_code, content, headers, timed_out, error_msg\n          INTO response_status, response_body, response_headers\n          FROM net._http_response \n          WHERE id = http_request_id;\n          \n          -- Check if we found a response\n          IF NOT FOUND THEN\n            insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] No response found for request ID: ' || http_request_id);\n            \n            -- Let's see what's in the response table\n            insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Checking all responses in table...');\n            \n            -- Log recent responses to debug\n            FOR response_status, response_body IN \n              SELECT status_code, content \n              FROM net._http_response \n              ORDER BY created DESC \n              LIMIT 3\n            LOOP\n              insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Recent response - Status: ' || COALESCE(response_status::text, 'NULL') || ', Body: ' || COALESCE(response_body, 'NULL'));\n            END LOOP;\n            \n          END IF;\n          \n        EXCEPTION WHEN OTHERS THEN\n          insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Error querying _http_response table: ' || SQLERRM);\n        END;\n        \n        insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Response Status: ' || COALESCE(response_status::text, 'NULL'));\n        insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Response Body: ' || COALESCE(response_body, 'NULL'));\n        insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] Response Headers: ' || COALESCE(response_headers::text, 'NULL'));\n        \n      EXCEPTION WHEN OTHERS THEN\n        insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] HTTP POST ERROR: ' || SQLERRM);\n        insert into public.debug_logs (message) VALUES ('[check_queue_size_and_trigger()] SQLSTATE: ' || SQLSTATE);\n      END;\n    END IF;\n  END IF;\n  \n  RETURN NEW;\nEND;\n$$ LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = private","CREATE TRIGGER \\"queue_threshhold\\" \n  AFTER INSERT ON \\"pgmq\\".\\"q_image-processing\\"\n  FOR EACH ROW \n  EXECUTE FUNCTION private.check_queue_size_and_trigger()"}	create_check_q_size_and_trigger
20250619175108	{"CREATE TABLE debug_logs (\n  id SERIAL PRIMARY KEY,\n  message TEXT,\n  created_at TIMESTAMP DEFAULT now()\n)","ALTER TABLE public.\\"debug_logs\\" ENABLE ROW LEVEL SECURITY","create policy \\"block_all\\"\non \\"public\\".\\"debug_logs\\"\nfor ALL\nto public\nusing (false)\nwith check (false)"}	create_debug_logs
20250619180110	{"-- Ensure the schema exists\ncreate schema if not exists pgmq_public","-- Grant usage on the schema to API roles\ngrant usage on schema pgmq_public to postgres, service_role","-- Wrapper functions in pgmq_public schema\n\ncreate or replace function pgmq_public.pop(queue_name text)\nreturns setof pgmq.message_record\nlanguage plpgsql\nset search_path = ''\nas $$\nbegin\n    return query\n    select * from pgmq.pop(queue_name := queue_name);\nend;\n$$","comment on function pgmq_public.pop(queue_name text) is\n'Retrieves and locks the next message from the specified queue.'","create or replace function pgmq_public.send(queue_name text, message jsonb, sleep_seconds integer default 0)\nreturns setof bigint\nlanguage plpgsql\nset search_path = ''\nas $$\nbegin\n    return query\n    select * from pgmq.send(queue_name := queue_name, msg := message, delay := sleep_seconds);\nend;\n$$","comment on function pgmq_public.send(queue_name text, message jsonb, sleep_seconds integer) is\n'Sends a message to the specified queue, optionally delaying its availability by a number of seconds.'","create or replace function pgmq_public.send_batch(queue_name text, messages jsonb[], sleep_seconds integer default 0)\nreturns setof bigint\nlanguage plpgsql\nset search_path = ''\nas $$\nbegin\n    return query\n    select * from pgmq.send_batch(queue_name := queue_name, msgs := messages, delay := sleep_seconds);\nend;\n$$","comment on function pgmq_public.send_batch(queue_name text, messages jsonb[], sleep_seconds integer) is\n'Sends a batch of messages to the specified queue, optionally delaying their availability by a number of seconds.'","create or replace function pgmq_public.archive(queue_name text, message_id bigint)\nreturns boolean\nlanguage plpgsql\nset search_path = ''\nas $$\nbegin\n    return pgmq.archive(queue_name := queue_name, msg_id := message_id);\nend;\n$$","comment on function pgmq_public.archive(queue_name text, message_id bigint) is\n'Archives a message by moving it from the queue to a permanent archive.'","create or replace function pgmq_public.delete(queue_name text, message_id bigint)\nreturns boolean\nlanguage plpgsql\nset search_path = ''\nas $$\nbegin\n    return pgmq.delete(queue_name := queue_name, msg_id := message_id);\nend;\n$$","comment on function pgmq_public.delete(queue_name text, message_id bigint) is\n'Permanently deletes a message from the specified queue.'","create or replace function pgmq_public.read(queue_name text, sleep_seconds integer, n integer)\nreturns setof pgmq.message_record\nlanguage plpgsql\nset search_path = ''\nas $$\nbegin\n    return query\n    select * from pgmq.read(queue_name := queue_name, vt := sleep_seconds, qty := n);\nend;\n$$","comment on function pgmq_public.read(queue_name text, sleep_seconds integer, n integer) is\n'Reads up to \\"n\\" messages from the specified queue with an optional \\"sleep_seconds\\" (visibility timeout).'","-- Grant EXECUTE on the wrapper functions to API roles\ngrant execute on function\n    pgmq_public.pop(text),\n    pgmq_public.send(text, jsonb, integer),\n    pgmq_public.send_batch(text, jsonb[], integer),\n    pgmq_public.archive(text, bigint),\n    pgmq_public.delete(text, bigint),\n    pgmq_public.read(text, integer, integer)\nto postgres, service_role, anon, authenticated","-- Grant EXECUTE on underlying pgmq functions (optional if used directly)\ngrant execute on function\n    pgmq.pop(text),\n    pgmq.send(text, jsonb, integer),\n    pgmq.send_batch(text, jsonb[], integer),\n    pgmq.archive(text, bigint),\n    pgmq.delete(text, bigint),\n    pgmq.read(text, integer, integer)\nto postgres, service_role, anon, authenticated","-- Grant table privileges for service_role\ngrant all privileges on all tables in schema pgmq to postgres, service_role","alter default privileges in schema pgmq grant all privileges on tables to postgres, service_role","grant usage on schema pgmq to postgres, service_role","-- Grant usage and access to sequences\ngrant usage, select, update on all sequences in schema pgmq to service_role","alter default privileges in schema pgmq grant usage, select, update on sequences to service_role"}	pgmq_expose_posgREST
20250624172357	{"-- Create contacts table with many-to-one relationship to companies\nCREATE TABLE public.contacts (\n    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,\n    company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,\n    name TEXT,\n    title TEXT,\n    email TEXT,\n    phone TEXT,\n    message TEXT,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,\n    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP\n)","-- Add index on company_id for better query performance\nCREATE INDEX idx_contacts_company_id ON public.contacts(company_id)","-- Add trigger to automatically update updated_at timestamp\nCREATE OR REPLACE FUNCTION update_updated_at_column()\nRETURNS TRIGGER AS $$\nBEGIN\n    NEW.updated_at = CURRENT_TIMESTAMP;\n    RETURN NEW;\nEND;\n$$ language 'plpgsql'","CREATE TRIGGER update_contacts_updated_at \n    BEFORE UPDATE ON public.contacts \n    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()"}	create_contacts_table
20250624180000	{"-- Add anonymous read access to companies table\nCREATE POLICY \\"allow_anonymous_read_companies\\"\nON public.companies\nFOR SELECT\nTO authenticated\nUSING (true)","-- Enable RLS on contacts table (not currently enabled)\nALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY","-- Add anonymous read access to contacts table\nCREATE POLICY \\"allow_anonymous_read_contacts\\"\nON public.contacts\nFOR SELECT\nTO authenticated\nUSING (true)","-- Add anonymous read access to gh-vehicle-photos bucket\nCREATE POLICY \\"allow_anonymous_read_gh_vehicle_photos\\"\nON storage.objects\nFOR SELECT\nTO authenticated\nUSING (bucket_id = 'gh-vehicle-photos')"}	add_anonymous_read_policies
20250624182212	{begin,"drop\n    publication if exists supabase_realtime","create publication supabase_realtime",commit,"alter\n    publication supabase_realtime add table public.companies, public.contacts"}	enable_realtime
20250624183000	{"-- CSV Export Functions for Companies and Contacts\n-- These functions generate CSV-formatted text for data export\n\n-- Function to export companies to CSV format\nCREATE OR REPLACE FUNCTION private.export_companies_csv()\nRETURNS TEXT AS $$\nDECLARE\n    csv_output TEXT;\nBEGIN\n    SELECT string_agg(csv_row, E'\\\\n') INTO csv_output\n    FROM (\n        SELECT 'name,industry,primary_email,email_list,primary_phone,phone_list,city,state,status,group' AS csv_row\n        UNION ALL\n        SELECT \n            quote_literal(name) || ',' ||\n            quote_literal(array_to_string(industry, ';')) || ',' ||\n            quote_literal(COALESCE(primary_email, '')) || ',' ||\n            quote_literal(array_to_string(email, ';')) || ',' ||\n            quote_literal(COALESCE(primary_phone, '')) || ',' ||\n            quote_literal(array_to_string(phone, ';')) || ',' ||\n            quote_literal(COALESCE(city, '')) || ',' ||\n            quote_literal(COALESCE(state, '')) || ',' ||\n            quote_literal(COALESCE(status, '')) || ',' ||\n            quote_literal(COALESCE(\\"group\\", '')) AS csv_row\n        FROM public.companies\n    ) all_data;\n    \n    RETURN COALESCE(csv_output, '');\nEND;\n$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = private","-- Function to export contacts with company information to CSV format  \nCREATE OR REPLACE FUNCTION private.export_contacts_csv()\nRETURNS TEXT AS $$\nDECLARE\n    csv_output TEXT;\nBEGIN\n    SELECT string_agg(csv_row, E'\\\\n') INTO csv_output\n    FROM (\n        SELECT 'company_name,contact_name,title,email,phone,message' AS csv_row\n        UNION ALL\n        SELECT \n            quote_literal(c.name) || ',' ||\n            quote_literal(COALESCE(ct.name, '')) || ',' ||\n            quote_literal(COALESCE(ct.title, '')) || ',' ||\n            quote_literal(COALESCE(ct.email, '')) || ',' ||\n            quote_literal(COALESCE(ct.phone, '')) || ',' ||\n            quote_literal(COALESCE(ct.message, '')) AS csv_row\n        FROM public.contacts ct\n        JOIN public.companies c ON ct.company_id = c.id\n    ) all_data;\n    \n    RETURN COALESCE(csv_output, '');\nEND;\n$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = private","-- Grant execute permissions to authenticated users\nGRANT EXECUTE ON FUNCTION private.export_companies_csv() TO authenticated","GRANT EXECUTE ON FUNCTION private.export_contacts_csv() TO authenticated"}	create_csv_export_functions
20250625000000	{"-- Grant permissions for net schema to allow HTTP requests from database functions\n\n-- Grant usage on net schema to service roles\nGRANT USAGE ON SCHEMA net TO service_role, postgres","-- Grant execute permissions on http_post function\nGRANT EXECUTE ON FUNCTION net.http_post TO service_role, postgres","-- Grant execute on all net functions for completeness\nGRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA net TO service_role, postgres"}	grant_net_permissions
20250625000001	{"-- Fix vehicle_photos foreign key constraint to reference companies table\n-- Drop existing incorrect constraint\nALTER TABLE public.\\"vehicle-photos\\" DROP CONSTRAINT IF EXISTS fk_company","-- Change company_id column type to UUID to match companies.id\nALTER TABLE public.\\"vehicle-photos\\" ALTER COLUMN company_id TYPE UUID USING company_id::text::uuid","-- Add correct foreign key constraint\nALTER TABLE public.\\"vehicle-photos\\"\nADD CONSTRAINT fk_company\nFOREIGN KEY (company_id) REFERENCES public.companies(id)\nON DELETE SET NULL"}	fix_vehicle_photos_fk
20250625000002	{"-- Add authenticated read access to vehicle-photos table\nCREATE POLICY \\"allow_authenticated_read_vehicle_photos\\"\nON public.\\"vehicle-photos\\"\nFOR SELECT\nTO authenticated\nUSING (true)"}	add_vehicle_photos_read_policy
\.


--
-- Data for Name: seed_files; Type: TABLE DATA; Schema: supabase_migrations; Owner: postgres
--

COPY supabase_migrations.seed_files (path, hash) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
93d00d8a-f6ae-48cb-9c3c-442578830741	worker_url		johN9/fK61jLQXCQ9a1CtRz7s8woDUapK2IXbXmyrZ3C/Xxyz6kuo+K6wNm95vQToVJEb6SfDY/s\nGGrMwHxShTJIUDXDJXN+IG7UG0xEXngqwBmVGBwcr8CjlB8=	\N	\\xcad48c8fc5d63d966bbe8487b7bde471	2025-06-24 02:37:13.204691+00	2025-06-25 04:13:22.570142+00
1fb72819-a4b1-4696-8b0f-9308b98f0916	jwt_secret		1pIrILbjmt74eDJ2kWHl/33x9C3wzV2gw6MTN6k71fsCNMI+8tGq217rvvSnf/SRMoOaAL8C2El9\nqhSRoLlL+E/JiDGDgP7/eVTWD7JO7m/JNPzR5yG9hZF3JnqWqxvCF1zeQkHqzWRm/OZpMyLnznTa\n7RVIjvEY	\N	\\x6bc16f2cfbfe0bad169330fbcdc63058	2025-06-25 04:43:50.644139+00	2025-06-25 04:43:50.644139+00
d28cfd32-befa-4a37-a5a9-d80624c035a7	supabase_service_role_key		ikyBY0KlV0E/Cwvf6tFqVpvxH9OW2tGHA9AX5FEfo8lLRN6ow6vfyUmdiDKGqnLJozXqDTEMW6iH\nPqvXSgm4aFKIJ8MBw//+50VDeWBqyQ7rAuVKmEQ9pYt0RPnesxOauFoY19k3fxM77LMlcySq2Bwl\nHh4EfITaAJwl4CvZJ8F+CenJTZ3wko9s4e0D+KdHuLH4NdCqZ2p0ymE/Sn2puPcC1l1t+2SB7eUf\nOq4608XCDG3De9KUfOx5e3CAznbZcoRlf43MSI4NsH/vwwGk6cBwAscFY5r6F2g7ULcmHZANb6nA\nvu47c5dDVuxkB2l+bXfrIE6xxSXPrts=	\N	\\x7c525b49120a0eefa4a04e82df494ed8	2025-06-22 16:59:56.356144+00	2025-06-25 05:34:33.098186+00
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 23, true);


--
-- Name: debug_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.debug_logs_id_seq', 82, true);


--
-- Name: vehicle-photos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."vehicle-photos_id_seq"', 18, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 2664, true);


--
-- Name: hooks_id_seq; Type: SEQUENCE SET; Schema: supabase_functions; Owner: supabase_functions_admin
--

SELECT pg_catalog.setval('supabase_functions.hooks_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: debug_logs debug_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debug_logs
    ADD CONSTRAINT debug_logs_pkey PRIMARY KEY (id);


--
-- Name: vehicle-photos vehicle-photos_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."vehicle-photos"
    ADD CONSTRAINT "vehicle-photos_name_key" UNIQUE (name);


--
-- Name: vehicle-photos vehicle-photos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."vehicle-photos"
    ADD CONSTRAINT "vehicle-photos_pkey" PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2025_06_24 messages_2025_06_24_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_06_24
    ADD CONSTRAINT messages_2025_06_24_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2025_06_25 messages_2025_06_25_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_06_25
    ADD CONSTRAINT messages_2025_06_25_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2025_06_26 messages_2025_06_26_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_06_26
    ADD CONSTRAINT messages_2025_06_26_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2025_06_27 messages_2025_06_27_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_06_27
    ADD CONSTRAINT messages_2025_06_27_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2025_06_28 messages_2025_06_28_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_06_28
    ADD CONSTRAINT messages_2025_06_28_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: hooks hooks_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.hooks
    ADD CONSTRAINT hooks_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (version);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: supabase_migrations; Owner: postgres
--

ALTER TABLE ONLY supabase_migrations.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: seed_files seed_files_pkey; Type: CONSTRAINT; Schema: supabase_migrations; Owner: postgres
--

ALTER TABLE ONLY supabase_migrations.seed_files
    ADD CONSTRAINT seed_files_pkey PRIMARY KEY (path);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: idx_contacts_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_contacts_company_id ON public.contacts USING btree (company_id);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: supabase_functions_hooks_h_table_id_h_name_idx; Type: INDEX; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE INDEX supabase_functions_hooks_h_table_id_h_name_idx ON supabase_functions.hooks USING btree (hook_table_id, hook_name);


--
-- Name: supabase_functions_hooks_request_id_idx; Type: INDEX; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE INDEX supabase_functions_hooks_request_id_idx ON supabase_functions.hooks USING btree (request_id);


--
-- Name: messages_2025_06_24_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_06_24_pkey;


--
-- Name: messages_2025_06_25_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_06_25_pkey;


--
-- Name: messages_2025_06_26_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_06_26_pkey;


--
-- Name: messages_2025_06_27_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_06_27_pkey;


--
-- Name: messages_2025_06_28_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_06_28_pkey;


--
-- Name: contacts update_contacts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_contacts_updated_at BEFORE UPDATE ON public.contacts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: objects on_new_image; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER on_new_image AFTER INSERT ON storage.objects FOR EACH ROW WHEN ((new.bucket_id = 'gh-vehicle-photos'::text)) EXECUTE FUNCTION public.insertimg();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: contacts contacts_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: vehicle-photos fk_company; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."vehicle-photos"
    ADD CONSTRAINT fk_company FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE SET NULL;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: companies allow_anonymous_read_companies; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_anonymous_read_companies ON public.companies FOR SELECT TO authenticated USING (true);


--
-- Name: contacts allow_anonymous_read_contacts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_anonymous_read_contacts ON public.contacts FOR SELECT TO authenticated USING (true);


--
-- Name: vehicle-photos allow_authenticated_read_vehicle_photos; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_authenticated_read_vehicle_photos ON public."vehicle-photos" FOR SELECT TO authenticated USING (true);


--
-- Name: companies block_all; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY block_all ON public.companies USING (false) WITH CHECK (false);


--
-- Name: debug_logs block_all; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY block_all ON public.debug_logs USING (false) WITH CHECK (false);


--
-- Name: vehicle-photos block_all; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY block_all ON public."vehicle-photos" USING (false) WITH CHECK (false);


--
-- Name: companies; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;

--
-- Name: contacts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;

--
-- Name: debug_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.debug_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: vehicle-photos; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public."vehicle-photos" ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: objects allow_anonymous_read_gh_vehicle_photos; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY allow_anonymous_read_gh_vehicle_photos ON storage.objects FOR SELECT TO authenticated USING ((bucket_id = 'gh-vehicle-photos'::text));


--
-- Name: objects block_all; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY block_all ON storage.objects USING (false) WITH CHECK (false);


--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- Name: supabase_realtime_messages_publication; Type: PUBLICATION; Schema: -; Owner: supabase_admin
--

CREATE PUBLICATION supabase_realtime_messages_publication WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime_messages_publication OWNER TO supabase_admin;

--
-- Name: supabase_realtime companies; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION supabase_realtime ADD TABLE ONLY public.companies;


--
-- Name: supabase_realtime contacts; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION supabase_realtime ADD TABLE ONLY public.contacts;


--
-- Name: supabase_realtime_messages_publication messages; Type: PUBLICATION TABLE; Schema: realtime; Owner: supabase_admin
--

ALTER PUBLICATION supabase_realtime_messages_publication ADD TABLE ONLY realtime.messages;


--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT USAGE ON SCHEMA auth TO postgres;


--
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- Name: SCHEMA net; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA net TO supabase_functions_admin;
GRANT USAGE ON SCHEMA net TO postgres;
GRANT USAGE ON SCHEMA net TO anon;
GRANT USAGE ON SCHEMA net TO authenticated;
GRANT USAGE ON SCHEMA net TO service_role;


--
-- Name: SCHEMA pgmq_public; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA pgmq_public TO service_role;


--
-- Name: SCHEMA private; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA private TO service_role;
GRANT USAGE ON SCHEMA private TO authenticated;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO postgres;
GRANT USAGE ON SCHEMA realtime TO anon;
GRANT USAGE ON SCHEMA realtime TO authenticated;
GRANT USAGE ON SCHEMA realtime TO service_role;
GRANT ALL ON SCHEMA realtime TO supabase_realtime_admin;


--
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA storage TO postgres;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- Name: SCHEMA supabase_functions; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA supabase_functions TO postgres;
GRANT USAGE ON SCHEMA supabase_functions TO anon;
GRANT USAGE ON SCHEMA supabase_functions TO authenticated;
GRANT USAGE ON SCHEMA supabase_functions TO service_role;
GRANT ALL ON SCHEMA supabase_functions TO supabase_functions_admin;


--
-- Name: SCHEMA vault; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA vault TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA vault TO service_role;


--
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- Name: FUNCTION algorithm_sign(signables text, secret text, algorithm text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.algorithm_sign(signables text, secret text, algorithm text) TO postgres WITH GRANT OPTION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.algorithm_sign(signables text, secret text, algorithm text) TO service_role;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.algorithm_sign(signables text, secret text, algorithm text) TO postgres;
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO service_role;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea, text[], text[]) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO service_role;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.crypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO service_role;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.dearmor(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO service_role;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO service_role;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO service_role;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO service_role;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO service_role;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO service_role;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO service_role;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_bytes(integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO service_role;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_uuid() FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO service_role;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO service_role;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text, integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO service_role;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO service_role;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres;
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO service_role;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO service_role;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) TO service_role;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO service_role;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) TO service_role;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO service_role;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_key_id(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO service_role;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO service_role;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO service_role;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO service_role;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO service_role;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO service_role;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO service_role;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO service_role;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO service_role;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO service_role;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO service_role;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO service_role;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO service_role;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO service_role;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO service_role;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO service_role;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO service_role;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO service_role;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO service_role;


--
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO service_role;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres;
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO service_role;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres;
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO service_role;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres;
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION sign(payload json, secret text, algorithm text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.sign(payload json, secret text, algorithm text) TO postgres WITH GRANT OPTION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.sign(payload json, secret text, algorithm text) TO service_role;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.sign(payload json, secret text, algorithm text) TO postgres;
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION try_cast_double(inp text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.try_cast_double(inp text) TO postgres WITH GRANT OPTION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.try_cast_double(inp text) TO service_role;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.try_cast_double(inp text) TO postgres;
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION url_decode(data text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.url_decode(data text) TO postgres WITH GRANT OPTION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.url_decode(data text) TO service_role;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.url_decode(data text) TO postgres;
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION url_encode(data bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.url_encode(data bytea) TO postgres WITH GRANT OPTION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.url_encode(data bytea) TO service_role;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.url_encode(data bytea) TO postgres;
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO service_role;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1mc() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO service_role;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO service_role;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v4() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO service_role;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO service_role;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_nil() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO service_role;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_dns() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO service_role;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_oid() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO service_role;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_url() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO service_role;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_x500() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO service_role;


--
-- Name: FUNCTION verify(token text, secret text, algorithm text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.verify(token text, secret text, algorithm text) TO postgres WITH GRANT OPTION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.verify(token text, secret text, algorithm text) TO service_role;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION postgres;
GRANT ALL ON FUNCTION extensions.verify(token text, secret text, algorithm text) TO postgres;
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO postgres;


--
-- Name: FUNCTION archive(queue_name text, msg_id bigint); Type: ACL; Schema: pgmq; Owner: postgres
--

GRANT ALL ON FUNCTION pgmq.archive(queue_name text, msg_id bigint) TO service_role;
GRANT ALL ON FUNCTION pgmq.archive(queue_name text, msg_id bigint) TO anon;
GRANT ALL ON FUNCTION pgmq.archive(queue_name text, msg_id bigint) TO authenticated;


--
-- Name: FUNCTION delete(queue_name text, msg_id bigint); Type: ACL; Schema: pgmq; Owner: postgres
--

GRANT ALL ON FUNCTION pgmq.delete(queue_name text, msg_id bigint) TO service_role;
GRANT ALL ON FUNCTION pgmq.delete(queue_name text, msg_id bigint) TO anon;
GRANT ALL ON FUNCTION pgmq.delete(queue_name text, msg_id bigint) TO authenticated;


--
-- Name: FUNCTION pop(queue_name text); Type: ACL; Schema: pgmq; Owner: postgres
--

GRANT ALL ON FUNCTION pgmq.pop(queue_name text) TO service_role;
GRANT ALL ON FUNCTION pgmq.pop(queue_name text) TO anon;
GRANT ALL ON FUNCTION pgmq.pop(queue_name text) TO authenticated;


--
-- Name: FUNCTION read(queue_name text, vt integer, qty integer); Type: ACL; Schema: pgmq; Owner: postgres
--

GRANT ALL ON FUNCTION pgmq.read(queue_name text, vt integer, qty integer) TO service_role;
GRANT ALL ON FUNCTION pgmq.read(queue_name text, vt integer, qty integer) TO anon;
GRANT ALL ON FUNCTION pgmq.read(queue_name text, vt integer, qty integer) TO authenticated;


--
-- Name: FUNCTION send(queue_name text, msg jsonb, delay integer); Type: ACL; Schema: pgmq; Owner: postgres
--

GRANT ALL ON FUNCTION pgmq.send(queue_name text, msg jsonb, delay integer) TO service_role;
GRANT ALL ON FUNCTION pgmq.send(queue_name text, msg jsonb, delay integer) TO anon;
GRANT ALL ON FUNCTION pgmq.send(queue_name text, msg jsonb, delay integer) TO authenticated;


--
-- Name: FUNCTION send_batch(queue_name text, msgs jsonb[], delay integer); Type: ACL; Schema: pgmq; Owner: postgres
--

GRANT ALL ON FUNCTION pgmq.send_batch(queue_name text, msgs jsonb[], delay integer) TO service_role;
GRANT ALL ON FUNCTION pgmq.send_batch(queue_name text, msgs jsonb[], delay integer) TO anon;
GRANT ALL ON FUNCTION pgmq.send_batch(queue_name text, msgs jsonb[], delay integer) TO authenticated;


--
-- Name: FUNCTION archive(queue_name text, message_id bigint); Type: ACL; Schema: pgmq_public; Owner: postgres
--

GRANT ALL ON FUNCTION pgmq_public.archive(queue_name text, message_id bigint) TO service_role;
GRANT ALL ON FUNCTION pgmq_public.archive(queue_name text, message_id bigint) TO anon;
GRANT ALL ON FUNCTION pgmq_public.archive(queue_name text, message_id bigint) TO authenticated;


--
-- Name: FUNCTION delete(queue_name text, message_id bigint); Type: ACL; Schema: pgmq_public; Owner: postgres
--

GRANT ALL ON FUNCTION pgmq_public.delete(queue_name text, message_id bigint) TO service_role;
GRANT ALL ON FUNCTION pgmq_public.delete(queue_name text, message_id bigint) TO anon;
GRANT ALL ON FUNCTION pgmq_public.delete(queue_name text, message_id bigint) TO authenticated;


--
-- Name: FUNCTION pop(queue_name text); Type: ACL; Schema: pgmq_public; Owner: postgres
--

GRANT ALL ON FUNCTION pgmq_public.pop(queue_name text) TO service_role;
GRANT ALL ON FUNCTION pgmq_public.pop(queue_name text) TO anon;
GRANT ALL ON FUNCTION pgmq_public.pop(queue_name text) TO authenticated;


--
-- Name: FUNCTION read(queue_name text, sleep_seconds integer, n integer); Type: ACL; Schema: pgmq_public; Owner: postgres
--

GRANT ALL ON FUNCTION pgmq_public.read(queue_name text, sleep_seconds integer, n integer) TO service_role;
GRANT ALL ON FUNCTION pgmq_public.read(queue_name text, sleep_seconds integer, n integer) TO anon;
GRANT ALL ON FUNCTION pgmq_public.read(queue_name text, sleep_seconds integer, n integer) TO authenticated;


--
-- Name: FUNCTION send(queue_name text, message jsonb, sleep_seconds integer); Type: ACL; Schema: pgmq_public; Owner: postgres
--

GRANT ALL ON FUNCTION pgmq_public.send(queue_name text, message jsonb, sleep_seconds integer) TO service_role;
GRANT ALL ON FUNCTION pgmq_public.send(queue_name text, message jsonb, sleep_seconds integer) TO anon;
GRANT ALL ON FUNCTION pgmq_public.send(queue_name text, message jsonb, sleep_seconds integer) TO authenticated;


--
-- Name: FUNCTION send_batch(queue_name text, messages jsonb[], sleep_seconds integer); Type: ACL; Schema: pgmq_public; Owner: postgres
--

GRANT ALL ON FUNCTION pgmq_public.send_batch(queue_name text, messages jsonb[], sleep_seconds integer) TO service_role;
GRANT ALL ON FUNCTION pgmq_public.send_batch(queue_name text, messages jsonb[], sleep_seconds integer) TO anon;
GRANT ALL ON FUNCTION pgmq_public.send_batch(queue_name text, messages jsonb[], sleep_seconds integer) TO authenticated;


--
-- Name: FUNCTION export_companies_csv(); Type: ACL; Schema: private; Owner: postgres
--

GRANT ALL ON FUNCTION private.export_companies_csv() TO authenticated;


--
-- Name: FUNCTION export_contacts_csv(); Type: ACL; Schema: private; Owner: postgres
--

GRANT ALL ON FUNCTION private.export_contacts_csv() TO authenticated;


--
-- Name: FUNCTION insertimg(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.insertimg() TO anon;
GRANT ALL ON FUNCTION public.insertimg() TO authenticated;
GRANT ALL ON FUNCTION public.insertimg() TO service_role;


--
-- Name: FUNCTION update_updated_at_column(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_updated_at_column() TO anon;
GRANT ALL ON FUNCTION public.update_updated_at_column() TO authenticated;
GRANT ALL ON FUNCTION public.update_updated_at_column() TO service_role;


--
-- Name: FUNCTION apply_rls(wal jsonb, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO supabase_realtime_admin;


--
-- Name: FUNCTION broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO postgres;
GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO dashboard_user;


--
-- Name: FUNCTION build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO postgres;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO anon;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO service_role;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION "cast"(val text, type_ regtype); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO postgres;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO dashboard_user;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO anon;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO authenticated;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO service_role;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO supabase_realtime_admin;


--
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO service_role;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO supabase_realtime_admin;


--
-- Name: FUNCTION is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO postgres;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO anon;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO service_role;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO supabase_realtime_admin;


--
-- Name: FUNCTION quote_wal2json(entity regclass); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO postgres;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO anon;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO authenticated;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO service_role;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO supabase_realtime_admin;


--
-- Name: FUNCTION send(payload jsonb, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION subscription_check_filters(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO postgres;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO anon;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO authenticated;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO service_role;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO supabase_realtime_admin;


--
-- Name: FUNCTION to_regrole(role_name text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO postgres;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO anon;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO authenticated;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO service_role;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO supabase_realtime_admin;


--
-- Name: FUNCTION topic(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.topic() TO postgres;
GRANT ALL ON FUNCTION realtime.topic() TO dashboard_user;


--
-- Name: FUNCTION http_request(); Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

REVOKE ALL ON FUNCTION supabase_functions.http_request() FROM PUBLIC;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO postgres;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO anon;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO authenticated;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO service_role;


--
-- Name: FUNCTION _crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO service_role;


--
-- Name: FUNCTION create_secret(new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: FUNCTION update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.flow_state TO dashboard_user;


--
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.identities TO dashboard_user;


--
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;


--
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.one_time_tokens TO dashboard_user;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;


--
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sessions TO dashboard_user;


--
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;


--
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;


--
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements TO dashboard_user;


--
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements_info FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO dashboard_user;


--
-- Name: TABLE companies; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.companies TO anon;
GRANT ALL ON TABLE public.companies TO authenticated;
GRANT ALL ON TABLE public.companies TO service_role;


--
-- Name: TABLE contacts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.contacts TO anon;
GRANT ALL ON TABLE public.contacts TO authenticated;
GRANT ALL ON TABLE public.contacts TO service_role;


--
-- Name: TABLE debug_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.debug_logs TO anon;
GRANT ALL ON TABLE public.debug_logs TO authenticated;
GRANT ALL ON TABLE public.debug_logs TO service_role;


--
-- Name: SEQUENCE debug_logs_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.debug_logs_id_seq TO anon;
GRANT ALL ON SEQUENCE public.debug_logs_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.debug_logs_id_seq TO service_role;


--
-- Name: TABLE "vehicle-photos"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."vehicle-photos" TO anon;
GRANT ALL ON TABLE public."vehicle-photos" TO authenticated;
GRANT ALL ON TABLE public."vehicle-photos" TO service_role;


--
-- Name: SEQUENCE "vehicle-photos_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."vehicle-photos_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."vehicle-photos_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."vehicle-photos_id_seq" TO service_role;


--
-- Name: TABLE messages; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.messages TO postgres;
GRANT ALL ON TABLE realtime.messages TO dashboard_user;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO anon;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO authenticated;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO service_role;


--
-- Name: TABLE messages_2025_06_24; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_06_24 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_06_24 TO dashboard_user;


--
-- Name: TABLE messages_2025_06_25; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_06_25 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_06_25 TO dashboard_user;


--
-- Name: TABLE messages_2025_06_26; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_06_26 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_06_26 TO dashboard_user;


--
-- Name: TABLE messages_2025_06_27; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_06_27 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_06_27 TO dashboard_user;


--
-- Name: TABLE messages_2025_06_28; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_06_28 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_06_28 TO dashboard_user;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.schema_migrations TO postgres;
GRANT ALL ON TABLE realtime.schema_migrations TO dashboard_user;
GRANT SELECT ON TABLE realtime.schema_migrations TO anon;
GRANT SELECT ON TABLE realtime.schema_migrations TO authenticated;
GRANT SELECT ON TABLE realtime.schema_migrations TO service_role;
GRANT ALL ON TABLE realtime.schema_migrations TO supabase_realtime_admin;


--
-- Name: TABLE subscription; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.subscription TO postgres;
GRANT ALL ON TABLE realtime.subscription TO dashboard_user;
GRANT SELECT ON TABLE realtime.subscription TO anon;
GRANT SELECT ON TABLE realtime.subscription TO authenticated;
GRANT SELECT ON TABLE realtime.subscription TO service_role;
GRANT ALL ON TABLE realtime.subscription TO supabase_realtime_admin;


--
-- Name: SEQUENCE subscription_id_seq; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO postgres;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO service_role;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO supabase_realtime_admin;


--
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO postgres;


--
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO postgres;


--
-- Name: TABLE s3_multipart_uploads; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO anon;


--
-- Name: TABLE s3_multipart_uploads_parts; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads_parts TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO anon;


--
-- Name: TABLE hooks; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON TABLE supabase_functions.hooks TO postgres;
GRANT ALL ON TABLE supabase_functions.hooks TO anon;
GRANT ALL ON TABLE supabase_functions.hooks TO authenticated;
GRANT ALL ON TABLE supabase_functions.hooks TO service_role;


--
-- Name: SEQUENCE hooks_id_seq; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO postgres;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO anon;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO authenticated;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO service_role;


--
-- Name: TABLE migrations; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON TABLE supabase_functions.migrations TO postgres;
GRANT ALL ON TABLE supabase_functions.migrations TO anon;
GRANT ALL ON TABLE supabase_functions.migrations TO authenticated;
GRANT ALL ON TABLE supabase_functions.migrations TO service_role;


--
-- Name: TABLE secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.secrets TO service_role;


--
-- Name: TABLE decrypted_secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.decrypted_secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.decrypted_secrets TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: pgmq; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pgmq GRANT SELECT ON SEQUENCES TO pg_monitor;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pgmq GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pgmq GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pgmq GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: pgmq; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pgmq GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pgmq GRANT SELECT ON TABLES TO pg_monitor;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pgmq GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES TO service_role;


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO supabase_admin;

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

--
-- PostgreSQL database dump complete
--

